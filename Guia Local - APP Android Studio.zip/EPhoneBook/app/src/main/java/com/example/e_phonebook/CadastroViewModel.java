package com.example.e_phonebook;

import android.net.Uri;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.List;

public class CadastroViewModel extends ViewModel {
    public final MutableLiveData<Uri> fotoPrincipal = new MutableLiveData<>();
    public final MutableLiveData<List<Uri>> fotosAdicionais = new MutableLiveData<>(new ArrayList<>());
    public final MutableLiveData<String> nomeEstabelecimento = new MutableLiveData<>();
    public final MutableLiveData<String> descricaoEstabelecimento = new MutableLiveData<>();
    public final MutableLiveData<String> segunda = new MutableLiveData<>();
    public final MutableLiveData<String> terca = new MutableLiveData<>();
    public final MutableLiveData<String> quarta = new MutableLiveData<>();
    public final MutableLiveData<String> quinta = new MutableLiveData<>();
    public final MutableLiveData<String> sexta = new MutableLiveData<>();
    public final MutableLiveData<String> sabado = new MutableLiveData<>();
    public final MutableLiveData<String> domingo = new MutableLiveData<>();

    public final MutableLiveData<List<String>> categorias = new MutableLiveData<>(new ArrayList<>());
    public final MutableLiveData<List<String>> tags = new MutableLiveData<>(new ArrayList<>());
    public final MutableLiveData<String> endereco = new MutableLiveData<>();
    public final MutableLiveData<List<String>> telefones = new MutableLiveData<>(new ArrayList<>());
    public final MutableLiveData<List<String>> emails = new MutableLiveData<>(new ArrayList<>());
    public final MutableLiveData<String> whatsapp = new MutableLiveData<>();
    public final MutableLiveData<String> instagram = new MutableLiveData<>();
    public final MutableLiveData<String> facebook = new MutableLiveData<>();
    public final MutableLiveData<Double> latitude = new MutableLiveData<>();
    public final MutableLiveData<Double> longitude = new MutableLiveData<>();
}
