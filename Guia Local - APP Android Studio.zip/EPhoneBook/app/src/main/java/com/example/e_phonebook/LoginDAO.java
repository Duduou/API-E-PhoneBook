package com.example.e_phonebook;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

@Dao
public interface LoginDAO {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(LoginEntity login);

    @Query("DELETE FROM LoginEntity")
    void deleteAll();

    @Query("SELECT * FROM LoginEntity LIMIT 1")
    LoginEntity getSavedLogin();
}