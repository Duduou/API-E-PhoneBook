package com.example.e_phonebook;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.room.Room;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Intent itMain = new Intent(this, MainActivity.class);
        Intent itLogin = new Intent(this, LoginActivity.class);

        EditText etNome = findViewById(R.id.etCadastroNome);
        EditText etEmail = findViewById(R.id.etCadastroEmail);
        EditText etSenha = findViewById(R.id.etCadastroSenha);
        EditText etConfirmarSenha = findViewById(R.id.etConfirmarSenha);
        Button btnRegistrar = findViewById(R.id.btnRegistrar);
        TextView txtVoltarLogin = findViewById(R.id.txtVoltarLogin);

        btnRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = etNome.getText().toString();
                String email = etEmail.getText().toString();
                String senha = etSenha.getText().toString();

                if (!senha.equals(etConfirmarSenha.getText().toString())) {
                    Toast.makeText(getApplicationContext(), "Senhas não conferem", Toast.LENGTH_SHORT).show();
                    return;
                }
                else {
                    RegisterRequest registerRequest = new RegisterRequest(nome, email, senha);

                    Call<RegisterResponse> registerCall = RetrofitClient.getInstance().getMyApi().register(registerRequest);
                    registerCall.enqueue(new Callback<RegisterResponse>() {
                        @Override
                        public void onResponse(Call<RegisterResponse> call, Response<RegisterResponse> response) {
                            if(response.isSuccessful()) {
                                String DATABASE_NAME = "E-PhoneBook-DB";

                                AppDatabase db = Room.databaseBuilder(getApplicationContext(),
                                                AppDatabase.class, DATABASE_NAME).
                                        fallbackToDestructiveMigration()
                                        .allowMainThreadQueries()
                                        .build();

                                LoginDAO loginDAO = db.loginDAO();

                                Toast.makeText(getApplicationContext(), "Registro realizado com sucesso", Toast.LENGTH_SHORT).show();
                                LoginEntity login = new LoginEntity();
                                login.email = email;
                                login.senha = senha;
                                loginDAO.insert(login);
                                startActivity(itMain);
                            }
                            else {
                                Toast.makeText(getApplicationContext(), "Dados inválidos", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<RegisterResponse> call, Throwable t) {
                            Toast.makeText(getApplicationContext(), "Erro:" + t.getMessage() , Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });

        txtVoltarLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(itLogin);
            }
        });
    }
}