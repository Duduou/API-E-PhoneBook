package com.example.e_phonebook;

public class TokenResponse {
    private String token;

    public String getToken() {
        return "Bearer " + token;
    }
    public void setToken(String token) {
        this.token = token;
    }
}
