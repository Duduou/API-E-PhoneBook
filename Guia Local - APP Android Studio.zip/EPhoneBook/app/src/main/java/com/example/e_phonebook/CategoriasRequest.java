package com.example.e_phonebook;

import java.util.List;

public class CategoriasRequest {
    private List<Integer> categoriaIds;
    public CategoriasRequest(List<Integer> categoriaIds) {
        this.categoriaIds = categoriaIds;
    }

    public List<Integer> getCategoriaIds() {
        return categoriaIds;
    }

    public void setCategoriaIds(List<Integer> categoriaIds) {
        this.categoriaIds = categoriaIds;
    }
}
