package com.example.e_phonebook;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {LoginEntity.class}, version = 4)
public abstract class AppDatabase extends RoomDatabase {
    public abstract LoginDAO loginDAO();
}

