package com.example.e_phonebook;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class LoginEntity {
    @PrimaryKey
    public int id = 1;

    public String email;
    public String senha;
}

