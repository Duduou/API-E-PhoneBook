package com.example.e_phonebook;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CategoryFilterFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CategoryFilterFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private static final String categoriaId = "categoriaId";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private int mCategoriaId;

    public CategoryFilterFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment CategoryFilterFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static CategoryFilterFragment newInstance(String param1, String param2) {
        CategoryFilterFragment fragment = new CategoryFilterFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
            mCategoriaId = getArguments().getInt("categoriaId");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_search, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        EditText etSearch = view.findViewById(R.id.etSearchCategoria);
        getEstabelecimentos(view, false);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                boolean isSearching;
                EditText etSearch = view.findViewById(R.id.etSearchCategoria);
                isSearching = !etSearch.getText().toString().isEmpty();
                getEstabelecimentos(view, isSearching);
            }
        });

    }

    private void getEstabelecimentos(View view, Boolean isSearching) {
        if (isSearching) {
            EditText etSearch = view.findViewById(R.id.etSearchCategoria);
            String q = etSearch.getText().toString();
            Call<List<Estabelecimento>> call = RetrofitClient.getInstance().getMyApi().getEstabelecimentosByNameQuery(q);
            call.enqueue(new Callback<List<Estabelecimento>>() {
                @Override
                public void onResponse(Call<List<Estabelecimento>> call, Response<List<Estabelecimento>> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        List<Estabelecimento> estabelecimentos = response.body();

                        List<Estabelecimento> filtrados = new ArrayList<>();
                        for (Estabelecimento e : estabelecimentos) {
                            if (e.getCategorias() != null) {
                                for (Categorias rel : e.getCategorias()) {
                                    if (rel.getCategoria().getId() == mCategoriaId) {
                                        filtrados.add(e);
                                        break;
                                    }
                                }
                            }
                        }



                        RecyclerView rvEstabelecimentos = view.findViewById(R.id.rvEstabelecimentosCategoria);

                        MeuAdaptador.OnItemClickListener listener = estabelecimento -> {
                            DetailFragment detailFragment = DetailFragment.newInstance(estabelecimento);

                            getParentFragmentManager()
                                    .beginTransaction()
                                    .replace(R.id.flFragment, detailFragment)
                                    .addToBackStack(null)
                                    .commit();
                        };

                        MeuAdaptador adaptador = new MeuAdaptador(filtrados, listener);

                        RecyclerView.LayoutManager layout =
                                new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);
                        rvEstabelecimentos.setLayoutManager(layout);
                        rvEstabelecimentos.setAdapter(adaptador);
                    } else {
                        Toast.makeText(getContext(), "Erro na resposta da API.", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<List<Estabelecimento>> call, Throwable t) {
                    Toast.makeText(getContext(), "Ocorreu um erro: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }
        else {
            Call<List<Estabelecimento>> call = RetrofitClient.getInstance().getMyApi().getEstabelecimentos();
            call.enqueue(new Callback<List<Estabelecimento>>() {
                @Override
                public void onResponse(Call<List<Estabelecimento>> call, Response<List<Estabelecimento>> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        List<Estabelecimento> estabelecimentos = response.body();

                        List<Estabelecimento> filtrados = new ArrayList<>();
                        for (Estabelecimento e : estabelecimentos) {
                            if (e.getCategorias() != null) {
                                for (Categorias rel : e.getCategorias()) {
                                    if (rel.getCategoria().getId() == mCategoriaId) {
                                        filtrados.add(e);
                                        break;
                                    }
                                }
                            }
                        }


                        RecyclerView rvEstabelecimentos = view.findViewById(R.id.rvEstabelecimentosCategoria);

                        MeuAdaptador.OnItemClickListener listener = estabelecimento -> {
                            DetailFragment detailFragment = DetailFragment.newInstance(estabelecimento);

                            getParentFragmentManager()
                                    .beginTransaction()
                                    .replace(R.id.flFragment, detailFragment)
                                    .addToBackStack(null)
                                    .commit();
                        };

                        MeuAdaptador adaptador = new MeuAdaptador(filtrados, listener);

                        RecyclerView.LayoutManager layout =
                                new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);
                        rvEstabelecimentos.setLayoutManager(layout);
                        rvEstabelecimentos.setAdapter(adaptador);
                    } else {
                        Toast.makeText(getContext(), "Erro na resposta da API.", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<List<Estabelecimento>> call, Throwable t) {
                    Toast.makeText(getContext(), "Ocorreu um erro: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}