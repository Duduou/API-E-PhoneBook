package com.example.e_phonebook;

import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.room.Room;

import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.Manifest;

import android.location.Address;
import android.location.Geocoder;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Cadastro2Fragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Cadastro2Fragment extends Fragment {

    private EditText etEndereco;
    private EditText etTelefone1;
    private EditText etTelefone2;
    private EditText etEmail1;
    private EditText etEmail2;
    private EditText etWhatsapp;
    private EditText etInstagram;
    private EditText etFacebook;
    private double latitude;
    private double longitude;
    private Button btnFinalizar;
    private CadastroEstabelecimentoRequest estabelecimento;
    private int idEstabelecimento;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable buscaEnderecoRunnable;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private Boolean mEditing;
    private Estabelecimento mEstabelecimento;

    public Cadastro2Fragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Cadastro2Fragment.
     */
    // TODO: Rename and change types and number of parameters
    public static Cadastro2Fragment newInstance(Boolean param1, Estabelecimento param2) {
        Cadastro2Fragment fragment = new Cadastro2Fragment();
        Bundle args = new Bundle();
        args.putBoolean(ARG_PARAM1, param1);
        args.putSerializable(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mEditing = getArguments().getBoolean(ARG_PARAM1);
            mEstabelecimento = (Estabelecimento) getArguments().getSerializable(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_cadastro2, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        etEndereco = view.findViewById(R.id.etEndereco);
        etTelefone1 = view.findViewById(R.id.etTelefone1);
        etTelefone2 = view.findViewById(R.id.etTelefone2);
        etEmail1 = view.findViewById(R.id.etEmail1);
        etEmail2 = view.findViewById(R.id.etEmail2);
        etWhatsapp = view.findViewById(R.id.etWhatsapp);
        etInstagram = view.findViewById(R.id.etInstagram);
        etFacebook = view.findViewById(R.id.etFacebook);
        btnFinalizar = view.findViewById(R.id.btnFinalizar);
        if (mEditing != null) {

            if(mEstabelecimento.getTelefones() != null) {
                List<Telefone> telefones = mEstabelecimento.getTelefones();
            }
            if(mEstabelecimento.getEmails() != null) {
                List<Email> emails = mEstabelecimento.getEmails();
            }
            if(mEstabelecimento.getEndereco() != null) {
                etEndereco.setText(mEstabelecimento.getEndereco());
            }
            if(mEstabelecimento.getTelefones().size() > 1 && mEstabelecimento.getTelefones().get(1).getNumero() != null) {
                etTelefone2.setText(mEstabelecimento.getTelefones().get(0).getNumero());
            }
            if(mEstabelecimento.getTelefones().size() > 0 && mEstabelecimento.getTelefones().get(0).getNumero() != null) {
                etTelefone1.setText(mEstabelecimento.getTelefones().get(0).getNumero());
            }
            if(mEstabelecimento.getEmails().size() > 1 && mEstabelecimento.getEmails().get(1).getEmail() != null) {
                etEmail2.setText(mEstabelecimento.getEmails().get(1).getEmail());
            }
            if(mEstabelecimento.getEmails().size() > 0 && mEstabelecimento.getEmails().get(0).getEmail() != null) {
                etEmail1.setText(mEstabelecimento.getEmails().get(0).getEmail());
            }
            if(mEstabelecimento.getWhatsapp() != null) {
                etWhatsapp.setText(mEstabelecimento.getWhatsapp());
            }
            if(mEstabelecimento.getInstagram() != null) {
                etInstagram.setText(mEstabelecimento.getInstagram());
            }
            if(mEstabelecimento.getFacebook() != null) {
                etFacebook.setText(mEstabelecimento.getFacebook());
            }
        }

        btnFinalizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String DATABASE_NAME = "E-PhoneBook-DB";
                AppDatabase db = Room.databaseBuilder(getContext(),
                                AppDatabase.class, DATABASE_NAME)
                        .fallbackToDestructiveMigration()
                        .allowMainThreadQueries()
                        .build();

                LoginDAO loginDAO = db.loginDAO();

                LoginEntity saved = loginDAO.getSavedLogin();
                LoginRequest loginRequest = new LoginRequest(saved.email, saved.senha);

                Call<TokenResponse> tokenCall = RetrofitClient.getInstance().getMyApi().login(loginRequest);
                tokenCall.enqueue(new Callback<TokenResponse>() {
                      @Override
                      public void onResponse(Call<TokenResponse> call, Response<TokenResponse> response) {
                          if(response.isSuccessful()) {
                              String token = response.body().getToken();
                              CadastroViewModel viewModel = new ViewModelProvider(requireActivity()).get(CadastroViewModel.class);;
                              estabelecimento = new CadastroEstabelecimentoRequest(
                                      viewModel.nomeEstabelecimento.getValue(),
                                      viewModel.descricaoEstabelecimento.getValue(),
                                      etEndereco.getText().toString(),
                                      latitude,
                                      longitude,
                                      etWhatsapp.getText().toString(),
                                      etFacebook.getText().toString(),
                                      etInstagram.getText().toString()
                              );

                              Call<Estabelecimento> callCriarEstabelecimetno;

                              if (mEditing != null) {
                                  callCriarEstabelecimetno = RetrofitClient.getInstance().getMyApi().editEstabelecimento(mEstabelecimento.getId(), estabelecimento, token);
                              }
                              else {
                                  callCriarEstabelecimetno = RetrofitClient.getInstance().getMyApi().createEstabelecimento(estabelecimento, token);
                              }

                              callCriarEstabelecimetno.enqueue(new Callback<Estabelecimento>() {
                                  @Override
                                  public void onResponse(Call<Estabelecimento> callCriarEstabelecimetno, Response<Estabelecimento> response) {
                                      if (response.isSuccessful()) {
                                          Estabelecimento createdEstabelecimento = response.body();
                                          if (createdEstabelecimento != null) {
                                              idEstabelecimento = createdEstabelecimento.getId();
                                              Uri fotoUri = viewModel.fotoPrincipal.getValue();
                                              if (fotoUri != null) {
                                                  String fotoStr = fotoUri.toString();
                                                  if (fotoStr.startsWith("http")) {
                                                      Log.d("UPLOAD", "Foto já está no servidor, pulando upload: " + fotoStr);
                                                  }
                                                  else {
                                                      File file = getFileFromUri(fotoUri);
                                                      if (file != null) {
                                                          RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), file);
                                                          MultipartBody.Part arquivoPart = MultipartBody.Part.createFormData("arquivo", file.getName(), requestFile);
                                                          Call<Void> uploadPrincipalCall = RetrofitClient.getInstance().getMyApi().uploadFotoPerfilEstabelecimento(idEstabelecimento, token, arquivoPart);

                                                          uploadPrincipalCall.enqueue(new Callback<Void>() {
                                                              @Override
                                                              public void onResponse(Call<Void> call, Response<Void> response) {
                                                                  Log.d("UPLOAD", "Upload concluído: " + response.code());
                                                              }

                                                              @Override
                                                              public void onFailure(Call<Void> call, Throwable t) {
                                                                  Log.e("UPLOAD", "Erro ao fazer upload", t);
                                                              }
                                                          });
                                                      } else {
                                                          Log.e("UPLOAD", "File é null para o Uri selecionado");
                                                      }
                                                  }
                                              }
                                              if (!viewModel.fotosAdicionais.getValue().isEmpty()) {
                                                  if (mEditing != null) {
                                                      for (Foto foto : mEstabelecimento.getFotos()){
                                                          Uri uri = viewModel.fotosAdicionais.getValue().get(0);
                                                          if (uri != null) {
                                                              if (uri.toString().startsWith("http")) {
                                                                  Log.d("UPLOAD_ADICIONAL", "Foto adicional já está no servidor, pulando... ");
                                                                  continue;
                                                              }
                                                          }
                                                          Call<Void> deletarFotosEstabelecimento = RetrofitClient.getInstance().getMyApi().deletarFotosEstabelecimento(foto.getId(), token);
                                                          deletarFotosEstabelecimento.enqueue(new Callback<Void>() {
                                                              @Override
                                                              public void onResponse(Call<Void> call, Response<Void> response) {
                                                                  if (response.isSuccessful()) {

                                                                  } else {
                                                                      Toast.makeText(requireContext(), "Erro 1 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                                  }
                                                              }

                                                              @Override
                                                              public void onFailure(Call<Void> call, Throwable t) {
                                                                  Toast.makeText(requireContext(), "Erro 2 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                              }
                                                          });
                                                      }
                                                  }

                                                  Log.d("UPLOAD", "Fotos adicionais: " + viewModel.fotosAdicionais.getValue());

                                                  for (Uri uri : viewModel.fotosAdicionais.getValue()) {
                                                      if (uri != null) {
                                                          String uriStr = uri.toString();

                                                          // Se for uma URL remota, não faz upload novamente
                                                          if (uriStr.startsWith("http")) {
                                                              Log.d("UPLOAD_ADICIONAL", "Foto adicional já está no servidor, pulando: " + uriStr);
                                                              continue;
                                                          }

                                                          // Se for um URI local, faz upload normalmente
                                                          File fileAdicional = getFileFromUri(uri);
                                                          if (fileAdicional != null) {
                                                              RequestBody requestFileAdicional = RequestBody.create(MediaType.parse("image/*"), fileAdicional);
                                                              MultipartBody.Part arquivoPartAdicional = MultipartBody.Part.createFormData("arquivo", fileAdicional.getName(), requestFileAdicional);

                                                              Call<Void> uploadAdicionalCall = RetrofitClient.getInstance().getMyApi()
                                                                      .uploadFotosEstabelecimento(idEstabelecimento, token, arquivoPartAdicional);

                                                              uploadAdicionalCall.enqueue(new Callback<Void>() {
                                                                  @Override
                                                                  public void onResponse(Call<Void> call, Response<Void> response) {
                                                                      if (response.isSuccessful()) {
                                                                          Log.d("UPLOAD_ADICIONAL", "Upload concluído: " + response.code());
                                                                      } else {
                                                                          Toast.makeText(requireContext(), "Erro ao enviar foto adicional", Toast.LENGTH_SHORT).show();
                                                                          Log.e("UPLOAD_ADICIONAL", "Erro: " + response.code());
                                                                      }
                                                                  }

                                                                  @Override
                                                                  public void onFailure(Call<Void> call, Throwable t) {
                                                                      Toast.makeText(requireContext(), "Erro ao enviar foto adicional", Toast.LENGTH_SHORT).show();
                                                                      Log.e("UPLOAD_ADICIONAL", "Falha no upload", t);
                                                                  }
                                                              });
                                                          } else {
                                                              Log.e("UPLOAD_ADICIONAL", "File adicional é null para Uri: " + uriStr);
                                                          }
                                                      }
                                                  }
                                              }
                                              if(!etTelefone1.getText().toString().isEmpty())
                                              {
                                                  if(mEditing != null) {
                                                      Call deletarTelefoneCall = RetrofitClient.getInstance().getMyApi().deletarTelefoneEstabelecimento(mEstabelecimento.getTelefones().get(0).getId(), token);
                                                      deletarTelefoneCall.enqueue(new Callback<Void>() {
                                                          @Override
                                                          public void onResponse(Call<Void> call, Response<Void> response) {
                                                              if (response.isSuccessful()) {

                                                              } else {
                                                                  Toast.makeText(requireContext(), "Erro 3 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                              }
                                                          }

                                                          @Override
                                                          public void onFailure(Call<Void> call, Throwable t) {
                                                              Toast.makeText(requireContext(), "Erro 4 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                          }
                                                      });
                                                  }
                                                  Call<Void> registrarTelefoneCall = RetrofitClient.getInstance().getMyApi().registrarTelefoneEstabelecimento(idEstabelecimento, token, new TelefoneRequest(etTelefone1.getText().toString()));
                                                  registrarTelefoneCall.enqueue(new Callback<Void>() {
                                                      @Override
                                                      public void onResponse(Call<Void> call, Response<Void> response) {
                                                          if (response.isSuccessful()) {

                                                          } else {
                                                              Toast.makeText(requireContext(), "Erro 5 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                          }
                                                      }

                                                      @Override
                                                      public void onFailure(Call<Void> call, Throwable t) {
                                                          Toast.makeText(requireContext(), "Erro 6 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                      }
                                                  });
                                              }
                                              if(!etTelefone2.getText().toString().isEmpty()) {
                                                  if(mEditing != null) {
                                                      Call deletarTelefone2Call = RetrofitClient.getInstance().getMyApi().deletarTelefoneEstabelecimento(mEstabelecimento.getTelefones().get(1).getId(), token);
                                                      deletarTelefone2Call.enqueue(new Callback<Void>() {
                                                          @Override
                                                          public void onResponse(Call<Void> call, Response<Void> response) {
                                                              if (response.isSuccessful()) {

                                                              } else {
                                                                  Toast.makeText(requireContext(), "Erro 7 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                              }
                                                          }

                                                          @Override
                                                          public void onFailure(Call<Void> call, Throwable t) {
                                                              Toast.makeText(requireContext(), "Erro 8 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                          }
                                                      });
                                                  }
                                                  Call<Void> registrarTelefone2Call = RetrofitClient.getInstance().getMyApi().registrarTelefoneEstabelecimento(idEstabelecimento, token, new TelefoneRequest(etTelefone2.getText().toString()));
                                                  registrarTelefone2Call.enqueue(new Callback<Void>() {
                                                      @Override
                                                      public void onResponse(Call<Void> call, Response<Void> response) {
                                                          if (response.isSuccessful()) {

                                                          } else {
                                                              Toast.makeText(requireContext(), "Erro 9 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                          }
                                                      }

                                                      @Override
                                                      public void onFailure(Call<Void> call, Throwable t) {
                                                          Toast.makeText(requireContext(), "Erro 10 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                      }
                                                  });
                                              }
                                              if(!etEmail1.getText().toString().isEmpty()) {
                                                  if(mEditing != null) {
                                                      Call deletarEmailCall = RetrofitClient.getInstance().getMyApi().deletarEmailEstabelecimento(mEstabelecimento.getEmails().get(0).getId(), token);
                                                      deletarEmailCall.enqueue(new Callback<Void>() {
                                                          @Override
                                                          public void onResponse(Call<Void> call, Response<Void> response) {
                                                              if (response.isSuccessful()) {

                                                              } else {
                                                                  Toast.makeText(requireContext(), "Erro 11 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                              }
                                                          }

                                                          @Override
                                                          public void onFailure(Call<Void> call, Throwable t) {
                                                              Toast.makeText(requireContext(), "Erro 12 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                          }
                                                      });
                                                  }
                                                  Call<Void> registrarEmailCall = RetrofitClient.getInstance().getMyApi().registrarEmailEstabelecimento(idEstabelecimento, token, new EmailRequest(etEmail1.getText().toString()));
                                                  registrarEmailCall.enqueue(new Callback<Void>() {
                                                      @Override
                                                      public void onResponse(Call<Void> call, Response<Void> response) {
                                                          if (response.isSuccessful()) {

                                                          } else {
                                                              Toast.makeText(requireContext(), "Erro 13 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                          }
                                                      }

                                                      @Override
                                                      public void onFailure(Call<Void> call, Throwable t) {
                                                          Toast.makeText(requireContext(), "Erro 14 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                      }
                                                  });
                                              }
                                              if(!etEmail2.getText().toString().isEmpty()) {
                                                  if(mEditing != null) {
                                                      Call deletarEmailCall = RetrofitClient.getInstance().getMyApi().deletarEmailEstabelecimento(mEstabelecimento.getEmails().get(1).getId(), token);
                                                      deletarEmailCall.enqueue(new Callback<Void>() {
                                                          @Override
                                                          public void onResponse(Call<Void> call, Response<Void> response) {
                                                              if (response.isSuccessful()) {

                                                              } else {
                                                                  Toast.makeText(requireContext(), "Erro 15 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                              }
                                                          }

                                                          @Override
                                                          public void onFailure(Call<Void> call, Throwable t) {
                                                              Toast.makeText(requireContext(), "Erro 16 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                          }
                                                      });
                                                  }
                                                  Call<Void> registrarEmail2Call = RetrofitClient.getInstance().getMyApi().registrarEmailEstabelecimento(idEstabelecimento, token, new EmailRequest(etEmail2.getText().toString()));
                                                  registrarEmail2Call.enqueue(new Callback<Void>() {
                                                      @Override
                                                      public void onResponse(Call<Void> call, Response<Void> response) {
                                                          if (response.isSuccessful()) {

                                                          } else {
                                                              Toast.makeText(requireContext(), "Erro 17 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                          }
                                                      }

                                                      @Override
                                                      public void onFailure(Call<Void> call, Throwable t) {
                                                          Toast.makeText(requireContext(), "Erro 18 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                      }
                                                  });
                                              }
                                              HorarioRequest horario = new HorarioRequest(
                                                      viewModel.domingo.getValue(),
                                                      viewModel.segunda.getValue(),
                                                      viewModel.terca.getValue(),
                                                      viewModel.quarta.getValue(),
                                                      viewModel.quinta.getValue(),
                                                      viewModel.sexta.getValue(),
                                                      viewModel.sabado.getValue()
                                              );
                                              Call<Void> registrarHorarioCall;
                                              if (mEditing != null) {
                                                  registrarHorarioCall = RetrofitClient.getInstance().getMyApi().atualizarHorarioEstabelecimento(idEstabelecimento, token, horario);
                                              }
                                              else {
                                                  registrarHorarioCall = RetrofitClient.getInstance().getMyApi().registrarHorarioEstabelecimento(idEstabelecimento, token, horario);
                                              }
                                              registrarHorarioCall.enqueue(new Callback<Void>() {
                                                  @Override
                                                  public void onResponse(Call<Void> call, Response<Void> response) {
                                                      if (response.isSuccessful()) {

                                                      } else {
                                                          Toast.makeText(requireContext(), "Erro 19 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                      }
                                                  }

                                                  @Override
                                                  public void onFailure(Call<Void> call, Throwable t) {
                                                      Toast.makeText(requireContext(), "Erro 20 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                  }
                                              });
                                              ProfileFragment profileFragment = new ProfileFragment();
                                              getParentFragmentManager()
                                                      .beginTransaction()
                                                      .replace(R.id.flFragment, profileFragment)
                                                      .addToBackStack(null)
                                                      .commit();

                                              Call<Estabelecimento> getEstabelecimentoCall = RetrofitClient.getInstance().getMyApi().getEstabelecimento(idEstabelecimento);
                                              getEstabelecimentoCall.enqueue(new Callback<Estabelecimento>() {
                                                  @Override
                                                  public void onResponse(Call<Estabelecimento> call, Response<Estabelecimento> response) {
                                                      if (response.isSuccessful()) {
                                                          Estabelecimento estabelecimento = response.body();

                                                          if (estabelecimento.getCategorias() != null && estabelecimento.getCategorias().size() > 0) {
                                                              List<Categorias> eCategorias = estabelecimento.getCategorias();
                                                              for (Categorias c : eCategorias) {
                                                                  Call<Void> deleteCategorias = RetrofitClient.getInstance().getMyApi().removerCategoriaEstabelecimento(estabelecimento.getId(), token, c.getCategoria().getId());
                                                                  deleteCategorias.enqueue(new Callback<Void>() {
                                                                      @Override
                                                                      public void onResponse(Call<Void> call, Response<Void> response) {
                                                                          if (response.isSuccessful()) {

                                                                          } else {
                                                                              Toast.makeText(requireContext(), "Erro 21 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                                          }
                                                                      }

                                                                      @Override
                                                                      public void onFailure(Call<Void> call, Throwable t) {
                                                                          Toast.makeText(requireContext(), "Erro 22 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                                      }
                                                                  });
                                                              }
                                                          }

                                                          if (estabelecimento.getTags() != null && estabelecimento.getTags().size() > 0) {
                                                              List<Tags> eTags = estabelecimento.getTags();
                                                              int estabelecimentoId = estabelecimento.getId();
                                                              for (Tags tags : eTags) {
                                                                  int tagID = tags.getTag().getId();
                                                                  Call<Void> deleteTags = RetrofitClient.getInstance().getMyApi().removerTagEstabelecimento(estabelecimentoId, token, tagID);
                                                                  deleteTags.enqueue(new Callback<Void>() {
                                                                      @Override
                                                                      public void onResponse(Call<Void> call, Response<Void> response) {
                                                                          if (response.isSuccessful()) {

                                                                          } else {
                                                                              Toast.makeText(requireContext(), "Erro 23 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                                          }
                                                                      }

                                                                      @Override
                                                                      public void onFailure(Call<Void> call, Throwable t) {
                                                                          Toast.makeText(requireContext(), "Erro 24 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                                      }
                                                                  });
                                                              }
                                                          }
                                                          if (!viewModel.categorias.getValue().isEmpty()) {
                                                              List<String> categoriasSelecionadas = viewModel.categorias.getValue();
                                                              List<Integer> idsCategorias = new ArrayList<>();
                                                              for (String categoriaS : categoriasSelecionadas) {
                                                                  idsCategorias.add(Integer.parseInt(categoriaS));
                                                              }
                                                              Call<Void> registrarCategoriasCall = RetrofitClient.getInstance().getMyApi().registrarCategoriasEstabelecimento(idEstabelecimento, token, new CategoriasRequest(idsCategorias));
                                                              registrarCategoriasCall.enqueue(new Callback<Void>() {
                                                                  @Override
                                                                  public void onResponse(Call<Void> call, Response<Void> response) {
                                                                      if (response.isSuccessful()) {

                                                                      }
                                                                      else {
                                                                          Toast.makeText(requireContext(), "Erro 27 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                                      }
                                                                  }
                                                                  @Override
                                                                  public void onFailure(Call<Void> call, Throwable t) {
                                                                      Toast.makeText(requireContext(), "Erro 28 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                                  }
                                                              });
                                                          }

                                                          if (!viewModel.tags.getValue().isEmpty()) {
                                                              List<String> tagsSelecionadas = viewModel.tags.getValue();
                                                              List<Integer> idsTags = new ArrayList<>();
                                                              for (String tagS : tagsSelecionadas) {
                                                                  idsTags.add(Integer.parseInt(tagS));
                                                              }
                                                              Call<Void> registrarTagsCall = RetrofitClient.getInstance().getMyApi().registrarTagsEstabelecimento(idEstabelecimento, token, new TagsRequest(idsTags));
                                                              registrarTagsCall.enqueue(new Callback<Void>() {
                                                                  @Override
                                                                  public void onResponse(Call<Void> call, Response<Void> response) {
                                                                      if (response.isSuccessful()) {

                                                                      }
                                                                      else {
                                                                          Toast.makeText(requireContext(), "Erro 29 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                                      }
                                                                  }
                                                                  @Override
                                                                  public void onFailure(Call<Void> call, Throwable t) {
                                                                      Toast.makeText(requireContext(), "Erro 30 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                                  }
                                                              });
                                                          }

                                                      } else {
                                                          Toast.makeText(requireContext(), "Erro 25 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                      }
                                                  }

                                                  @Override
                                                  public void onFailure(Call<Estabelecimento> call, Throwable t) {
                                                      Toast.makeText(requireContext(), "Erro 26 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                                  }
                                              });
                                          }
                                          else {
                                            Toast.makeText(requireContext(), "Erro 31 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                          }
                                      }
                                      else {
                                        Toast.makeText(requireContext(), "Erro 32 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                      }
                                  }
                                  @Override
                                  public void onFailure(Call<Estabelecimento> call, Throwable t) {
                                    Toast.makeText(requireContext(), "Erro 33 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                                  }
                              });
                          }
                      }

                      @Override
                      public void onFailure(Call<TokenResponse> call, Throwable t) {
                        Toast.makeText(requireContext(), "Erro 34 ao criar estabelecimento", Toast.LENGTH_SHORT).show();
                      }
                });
            }
        });

        SupportMapFragment mapFragment = (SupportMapFragment)
                getChildFragmentManager().findFragmentById(R.id.flMapaCadastro);

        if (mapFragment != null) {
            mapFragment.getMapAsync(googleMap -> {

                FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity());

                if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED) {

                    fusedLocationClient.getLastLocation().addOnSuccessListener(requireActivity(), location -> {
                        if (location != null) {

                            LatLng localAtual = new LatLng(location.getLatitude(), location.getLongitude());

                            // Salva coordenadas no fragment
                            if (mEditing != null) {
                                latitude = mEstabelecimento.getLatitude();
                                longitude = mEstabelecimento.getLongitude();
                                localAtual = new LatLng(longitude, latitude);
                            }
                            else {
                                longitude = localAtual.latitude;
                                latitude = localAtual.longitude;
                            }

                            // Adiciona marcador e move câmera
                            googleMap.clear();
                            googleMap.addMarker(new MarkerOptions().position(localAtual).title("Minha localização"));
                            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(localAtual, 15));
                        } else {
                            Log.d("MAPA", "Localização atual é nula");
                        }
                    });

                } else {
                    // Solicita permissão de localização
                    ActivityCompat.requestPermissions(requireActivity(),
                            new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1001);
                }

                // Inicializa e configura o TextWatcher com delay
                etEndereco.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        // Cancela busca anterior
                        handler.removeCallbacks(buscaEnderecoRunnable);
                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                        final String textoEndereco = s.toString().trim();

                        // Agenda nova busca após 1 segundo sem digitação
                        buscaEnderecoRunnable = () -> {
                            if (!textoEndereco.isEmpty()) {
                                Geocoder geocoder = new Geocoder(requireContext(), Locale.getDefault());
                                try {
                                    List<Address> resultados = geocoder.getFromLocationName(textoEndereco, 1);
                                    if (resultados != null && !resultados.isEmpty()) {
                                        Address endereco = resultados.get(0);
                                        LatLng local = new LatLng(endereco.getLatitude(), endereco.getLongitude());

                                        googleMap.clear();
                                        googleMap.addMarker(new MarkerOptions().position(local).title("Endereço encontrado"));
                                        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(local, 15));

                                        longitude = local.latitude;
                                        latitude = local.longitude;
                                    } else {
                                        Log.d("MAPA", "Endereço não encontrado");
                                    }
                                } catch (Exception e) {
                                    Log.e("MAPA", "Erro 35 ao buscar endereço: " + e.getMessage());
                                }
                            }
                        };

                        handler.postDelayed(buscaEnderecoRunnable, 1000); // 1000 ms = 1 segundo
                    }
                });
            });
        }
    }

    private File getFileFromUri(Uri uri) {
        String path = RealPathUtil.getRealPath(requireContext(), uri);
        return new File(path);
    }
}