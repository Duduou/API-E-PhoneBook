package com.example.e_phonebook;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.room.Room;

import java.io.File;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Intent itMain = new Intent(this, MainActivity.class);
        Intent itRegister = new Intent(this, RegisterActivity.class);

        EditText etEmail = findViewById(R.id.etLoginEmail);
        EditText etSenha = findViewById(R.id.etLoginSenha);
        Button btnLogin = findViewById(R.id.btnLogin);
        TextView txtCadastro = findViewById(R.id.txtCadastro);

        btnLogin.setOnClickListener(v -> {
            String email = etEmail.getText().toString();
            String senha = etSenha.getText().toString();
            LoginRequest loginRequest = new LoginRequest(email, senha);

            Call<TokenResponse> tokenCall = RetrofitClient.getInstance().getMyApi().login(loginRequest);
            tokenCall.enqueue(new Callback<TokenResponse>() {
                @Override
                public void onResponse(Call<TokenResponse> call, Response<TokenResponse> response) {
                    if(response.isSuccessful()) {
                        String DATABASE_NAME = "E-PhoneBook-DB";

                        AppDatabase db = Room.databaseBuilder(getApplicationContext(),
                                AppDatabase.class, DATABASE_NAME).
                                fallbackToDestructiveMigration()
                                .allowMainThreadQueries()
                                .build();

                        LoginDAO loginDAO = db.loginDAO();

                        Toast.makeText(getApplicationContext(), "Login realizado com sucesso", Toast.LENGTH_SHORT).show();
                        LoginEntity login = new LoginEntity();
                        login.email = email;
                        login.senha = senha;
                        loginDAO.insert(login);
                        startActivity(itMain);
                    }
                    else {
                        Toast.makeText(getApplicationContext(), "Email ou Senha incorretos", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<TokenResponse> call, Throwable t) {
                    Toast.makeText(getApplicationContext(), "Erro ao realizar Login", Toast.LENGTH_SHORT).show();
                }
            });

        });

        txtCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(itRegister);
            }
        });
    }
}