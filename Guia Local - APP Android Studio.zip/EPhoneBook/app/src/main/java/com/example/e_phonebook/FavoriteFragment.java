package com.example.e_phonebook;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FavoriteFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FavoriteFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public FavoriteFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment FavoritesFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static FavoriteFragment newInstance(String param1, String param2) {
        FavoriteFragment fragment = new FavoriteFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_favorites, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        EditText etSearch = view.findViewById(R.id.etSearchFav);
        getEstabelecimentos(view, false);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                boolean isSearching;
                EditText etSearch = view.findViewById(R.id.etSearchFav);
                isSearching = !etSearch.getText().toString().isEmpty();
                getEstabelecimentos(view, isSearching);
            }
        });

    }

    private void getEstabelecimentos(View view, Boolean isSearching) {
        String DATABASE_NAME = "E-PhoneBook-DB";
        AppDatabase db = Room.databaseBuilder(getContext(),
                        AppDatabase.class, DATABASE_NAME)
                .fallbackToDestructiveMigration()
                .allowMainThreadQueries()
                .build();

        LoginDAO loginDAO = db.loginDAO();

        LoginEntity saved = loginDAO.getSavedLogin();
        LoginRequest loginRequest = new LoginRequest(saved.email, saved.senha);

        Call<TokenResponse> tokenCall = RetrofitClient.getInstance().getMyApi().login(loginRequest);
        tokenCall.enqueue(new Callback<TokenResponse>() {
            @Override
            public void onResponse(Call<TokenResponse> call, Response<TokenResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    String token = response.body().getToken();
                    Call<List<Estabelecimento>> favoritosCall = RetrofitClient.getInstance().getMyApi().getFavoritos(token);
                    favoritosCall.enqueue(new Callback<List<Estabelecimento>>() {
                        @Override
                        public void onResponse(Call<List<Estabelecimento>> call, Response<List<Estabelecimento>> response) {
                            if (response.isSuccessful() && response.body() != null) {

                                List<Estabelecimento> favoritos = response.body();

                                List<Estabelecimento> resultados = favoritos; // padrão: mostra todos

                                if (isSearching) {
                                    EditText etSearch = view.findViewById(R.id.etSearchFav);
                                    String q = etSearch.getText().toString().toLowerCase().trim();

                                    resultados = new ArrayList<>();
                                    for (Estabelecimento e : favoritos) {
                                        if (e.getNome() != null && e.getNome().toLowerCase().contains(q)) {
                                            resultados.add(e);
                                        }
                                    }
                                }

                                RecyclerView rvEstabelecimentos = view.findViewById(R.id.rvEstabelecimentosFav);

                                MeuAdaptador.OnItemClickListener listener = estabelecimento -> {
                                    DetailFragment detailFragment = DetailFragment.newInstance(estabelecimento);

                                    getParentFragmentManager()
                                            .beginTransaction()
                                            .replace(R.id.flFragment, detailFragment)
                                            .addToBackStack(null)
                                            .commit();
                                };

                                MeuAdaptador adaptador = new MeuAdaptador(resultados, listener);

                                RecyclerView.LayoutManager layout =
                                        new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);
                                rvEstabelecimentos.setLayoutManager(layout);
                                rvEstabelecimentos.setAdapter(adaptador);
                            }
                            else {
                                Toast.makeText(getContext(), "Erro na resposta da API.", Toast.LENGTH_SHORT).show();
                            }
                        }
                        @Override
                        public void onFailure(Call<List<Estabelecimento>> call, Throwable t) {
                            Toast.makeText(getContext(), "Erro: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });

                } else {
                    Toast.makeText(getContext(), "Erro na resposta da API.", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onFailure(Call<TokenResponse> call, Throwable t) {
                Toast.makeText(getContext(), "Erro: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}