package com.example.e_phonebook;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.room.Room;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Cadastro1Fragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Cadastro1Fragment extends Fragment {

    private ActivityResultLauncher<Intent> galeriaLauncher;
    private ActivityResultLauncher<Intent> fotoPerfilLauncher;
    private ImageView ivFotoPerfil;
    private CadastroViewModel viewModel;
    private LinearLayout layoutMiniaturas;
    private LinearLayout btnAdicionarFoto;
    private Button btnAvancar;
    private Button btnAdicionarFotos;
    private EditText etNomeEstabelecimento;
    private EditText etDescricao;
    private EditText etSegunda;
    private EditText etTerca;
    private EditText etQuarta;
    private EditText etQuinta;
    private EditText etSexta;
    private EditText etSabado;
    private EditText etDomingo;
    private Button btnSelecionarCategorias;
    private Button btnSelecionarTags;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private Boolean mEditing;
    private Estabelecimento mEstabelecimento;

    public Cadastro1Fragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Cadastro1Fragment.
     */
    // TODO: Rename and change types and number of parameters
    public static Cadastro1Fragment newInstance(Boolean param1, Estabelecimento param2) {
        Cadastro1Fragment fragment = new Cadastro1Fragment();
        Bundle args = new Bundle();
        args.putBoolean(ARG_PARAM1, param1);
        args.putSerializable(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mEditing = getArguments().getBoolean(ARG_PARAM1);
            mEstabelecimento = (Estabelecimento) getArguments().getSerializable(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_cadastro1, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Button btnApagar = view.findViewById(R.id.btnApagar);
        if (mEditing != null && mEstabelecimento != null) {
            btnApagar.setVisibility(View.VISIBLE);
            btnApagar.setOnClickListener(v -> {
                String DATABASE_NAME = "E-PhoneBook-DB";
                AppDatabase db = Room.databaseBuilder(getContext(),
                                AppDatabase.class, DATABASE_NAME)
                        .fallbackToDestructiveMigration()
                        .allowMainThreadQueries()
                        .build();

                LoginDAO loginDAO = db.loginDAO();

                LoginEntity saved = loginDAO.getSavedLogin();
                LoginRequest loginRequest = new LoginRequest(saved.email, saved.senha);

                Call<TokenResponse> tokenCall = RetrofitClient.getInstance().getMyApi().login(loginRequest);
                tokenCall.enqueue(new Callback<TokenResponse>() {
                    @Override
                    public void onResponse(Call<TokenResponse> call, Response<TokenResponse> response) {
                        if(response.isSuccessful()) {
                            String token = response.body().getToken();
                            Call<Void> deleteEstabelecimento = RetrofitClient.getInstance().getMyApi().deletarEstabelecimento(mEstabelecimento.getId(), token);
                            deleteEstabelecimento.enqueue(new Callback<Void>() {
                                @Override
                                public void onResponse(Call<Void> call, Response<Void> response) {
                                    if (response.isSuccessful()) {
                                        Toast.makeText(getContext(), "Estabelecimento apagado", Toast.LENGTH_SHORT).show();
                                        requireActivity().getSupportFragmentManager().popBackStack();
                                    }
                                    else {
                                        Toast.makeText(getContext(), "Erro 1 ao apagar estabelecimento", Toast.LENGTH_SHORT).show();
                                    }
                                }
                                @Override
                                public void onFailure(Call<Void> call, Throwable t) {
                                    Toast.makeText(getContext(), "Erro 2 ao apagar estabelecimento", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                        else {
                            Toast.makeText(requireContext(), "Erro ao fazer login", Toast.LENGTH_SHORT).show();
                        }
                    }
                    @Override
                    public void onFailure(Call<TokenResponse> call, Throwable t) {
                        Toast.makeText(requireContext(), "Erro ao fazer login", Toast.LENGTH_SHORT).show();
                    }
                });
            });
        }

        layoutMiniaturas = view.findViewById(R.id.layoutMiniaturas);
        viewModel = new ViewModelProvider(requireActivity()).get(CadastroViewModel.class);
        btnAvancar = view.findViewById(R.id.btnAvancar);
        btnAdicionarFotos = view.findViewById(R.id.btnAdicionarFotos);
        btnAdicionarFoto = view.findViewById(R.id.btnAdicionarFoto);
        ivFotoPerfil = view.findViewById(R.id.ivFotoPerfil);
        etNomeEstabelecimento = view.findViewById(R.id.etNomeEstabelecimento);
        etDescricao = view.findViewById(R.id.etDescricao);
        etSegunda = view.findViewById(R.id.etSegunda);
        etTerca = view.findViewById(R.id.etTerca);
        etQuarta = view.findViewById(R.id.etQuarta);
        etQuinta = view.findViewById(R.id.etQuinta);
        etSexta = view.findViewById(R.id.etSexta);
        etSabado = view.findViewById(R.id.etSabado);
        etDomingo = view.findViewById(R.id.etDomingo);

        btnSelecionarCategorias = view.findViewById(R.id.btnSelecionarCategoria);

        btnSelecionarCategorias.setOnClickListener(v -> mostrarDialogCategorias());

        btnSelecionarTags = view.findViewById(R.id.btnSelecionarTags);

        btnSelecionarTags.setOnClickListener(v -> mostrarDialogTags());

        if (mEditing != null) {
            etNomeEstabelecimento.setText(mEstabelecimento.getNome());
            etDescricao.setText(mEstabelecimento.getDescricao());
            etSegunda.setText(mEstabelecimento.getHorario().getSeg());
            etTerca.setText(mEstabelecimento.getHorario().getTer());
            etQuarta.setText(mEstabelecimento.getHorario().getQua());
            etQuinta.setText(mEstabelecimento.getHorario().getQui());
            etSexta.setText(mEstabelecimento.getHorario().getSex());
            etSabado.setText(mEstabelecimento.getHorario().getSab());
            etDomingo.setText(mEstabelecimento.getHorario().getDom());
            Picasso.get()
                    .load(mEstabelecimento.getFotoPerfil())
                    .resize(200, 200)
                    .centerCrop()
                    .into(ivFotoPerfil);

            if (mEstabelecimento.getFotos() != null && !mEstabelecimento.getFotos().isEmpty()) {
                layoutMiniaturas.removeAllViews();

                for (Foto foto : mEstabelecimento.getFotos()) {
                    String urlFoto = foto.getUrl();
                    ImageView imageView = new ImageView(requireContext());

                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.WRAP_CONTENT,
                            (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 200, getResources().getDisplayMetrics())
                    );
                    params.setMargins(8, 0, 8, 0);
                    imageView.setLayoutParams(params);
                    imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);

                    Picasso.get()
                            .load(urlFoto)
                            .resize(0, 500)
                            .onlyScaleDown()
                            .into(imageView);

                    layoutMiniaturas.addView(imageView);
                }
            }
        }

        if (mEstabelecimento != null && mEstabelecimento.getFotoPerfil() != null && !mEstabelecimento.getFotoPerfil().isEmpty()) {
            Uri uriPerfil = Uri.parse(mEstabelecimento.getFotoPerfil());
            viewModel.fotoPrincipal.setValue(uriPerfil);
        }

        if (mEstabelecimento != null && mEstabelecimento.getFotos() != null && !mEstabelecimento.getFotos().isEmpty()) {
            List<Uri> uris = new ArrayList<>();
            for (Foto foto : mEstabelecimento.getFotos()) {
                Uri uriFoto = Uri.parse(foto.getUrl());
                uris.add(uriFoto);
            }
            viewModel.fotosAdicionais.setValue(uris);
        }

        btnAvancar.setOnClickListener(v -> {
            viewModel.nomeEstabelecimento.setValue(etNomeEstabelecimento.getText().toString());
            viewModel.descricaoEstabelecimento.setValue(etDescricao.getText().toString());
            viewModel.segunda.setValue(etSegunda.getText().toString());
            viewModel.terca.setValue(etTerca.getText().toString());
            viewModel.quarta.setValue(etQuarta.getText().toString());
            viewModel.quinta.setValue(etQuinta.getText().toString());
            viewModel.sexta.setValue(etSexta.getText().toString());
            viewModel.sabado.setValue(etSabado.getText().toString());
            viewModel.domingo.setValue(etDomingo.getText().toString());

            if(mEstabelecimento != null && mEstabelecimento.getCategorias().size() > 0 && viewModel.tags.getValue().isEmpty()) {
                List<String> mCategorias = new ArrayList<>();
                for (Categorias c : mEstabelecimento.getCategorias()) {
                    mCategorias.add(c.getCategoria().getId().toString());
                }
                viewModel.categorias.setValue(mCategorias);
            }

            if(mEstabelecimento != null && mEstabelecimento.getTags().size() > 0 && viewModel.tags.getValue().isEmpty()) {
                List<String> mTags = new ArrayList<>();
                for (Tags t : mEstabelecimento.getTags()) {
                    mTags.add(t.getTag().getId().toString());
                }
                viewModel.tags.setValue(mTags);
            }

            if(mEstabelecimento != null && mEstabelecimento.getFotos().size() > 0 && viewModel.fotosAdicionais.getValue().isEmpty()) {
                List<Uri> mFotos = new ArrayList<>();
                for (Foto f : mEstabelecimento.getFotos()) {
                    mFotos.add(Uri.parse(f.getUrl()));
                }
                viewModel.fotosAdicionais.setValue(mFotos);
            }

            if (mEditing != null) {
                Cadastro2Fragment cadastro2Fragment = Cadastro2Fragment.newInstance(true, mEstabelecimento);
                getParentFragmentManager()
                        .beginTransaction()
                        .replace(R.id.flFragment, cadastro2Fragment)
                        .addToBackStack(null)
                        .commit();
            }
            else {
                Cadastro2Fragment cadastro2Fragment = new Cadastro2Fragment();
                getParentFragmentManager()
                        .beginTransaction()
                        .replace(R.id.flFragment, cadastro2Fragment)
                        .addToBackStack(null)
                        .commit();
            }
        });

        fotoPerfilLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    Uri uri = result.getData().getData();
                    int dp = 120;
                    float scale = getResources().getDisplayMetrics().density;
                    int pixels = (int) (dp * scale + 0.5f);

                    ViewGroup.LayoutParams params = ivFotoPerfil.getLayoutParams();
                    params.width = pixels;
                    params.height = pixels;
                    ivFotoPerfil.setLayoutParams(params);

                    Picasso.get()
                            .load(uri)
                            .resize(200, 200)
                            .centerCrop()
                            .into(ivFotoPerfil);

                    viewModel.fotoPrincipal.setValue(uri);
                }
            });

        btnAdicionarFoto.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");
            fotoPerfilLauncher.launch(Intent.createChooser(intent, "Selecione a foto de perfil"));
        });

        // Registrar o launcher para múltiplas imagens
        galeriaLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        Intent data = result.getData();
                        List<Uri> uris = new ArrayList<>();

                        if (data.getClipData() != null) {
                            int count = data.getClipData().getItemCount();
                            for (int i = 0; i < count; i++) {
                                uris.add(data.getClipData().getItemAt(i).getUri());
                            }
                        } else if (data.getData() != null) {
                            uris.add(data.getData());
                        }

                        for (Uri uri : uris) {
                            ImageView imageView = new ImageView(requireContext());

                            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.WRAP_CONTENT,
                                    (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 200, getResources().getDisplayMetrics())
                            );
                            params.setMargins(8, 0, 8, 0); // margem entre imagens
                            imageView.setLayoutParams(params);
                            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);

                            Picasso.get()
                                    .load(uri)
                                    .resize(0, 500)        // 0 para largura deixa Picasso calcular mantendo o aspecto
                                    .onlyScaleDown()       // não aumenta se a imagem já for menor
                                    .into(imageView);

                            layoutMiniaturas.addView(imageView);
                        }

                        viewModel.fotosAdicionais.setValue(uris);
                    }
                });

        btnAdicionarFotos.setOnClickListener(v -> {
            layoutMiniaturas.removeAllViews();
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            galeriaLauncher.launch(Intent.createChooser(intent, "Selecione as fotos"));
        });
    }

    private void mostrarDialogCategorias() {
        // Infla o layout do diálogo
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_categorias, null);

        EditText etPesquisar = dialogView.findViewById(R.id.etPesquisarCategoria);
        ListView listView = dialogView.findViewById(R.id.listViewCategorias);
        Button btnSalvar = dialogView.findViewById(R.id.btnSalvarCategorias);

        // Lista de categorias
        Call<List<Categoria>> categoriasCall = RetrofitClient.getInstance().getMyApi().getCategorias();
        categoriasCall.enqueue(new Callback<List<Categoria>>() {
            @Override
            public void onResponse(Call<List<Categoria>> call, Response<List<Categoria>> response) {
                if (response.isSuccessful()) {
                    List<String> categorias = new ArrayList<>();
                    List<Categoria> categoriasList = response.body();

                    if (categoriasList != null) {
                        Collections.sort(categoriasList, new Comparator<Categoria>() {
                            @Override
                            public int compare(Categoria c1, Categoria c2) {
                                return c1.getNome().compareToIgnoreCase(c2.getNome());
                            }
                        });
                    }

                    for (Categoria c : categoriasList) {
                        categorias.add(c.getNome());
                    }

                    // Adapter padrão com múltipla seleção
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(
                            getContext(),
                            android.R.layout.simple_list_item_multiple_choice,
                            categorias
                    );
                    listView.setAdapter(adapter);

                    // Filtro de pesquisa
                    etPesquisar.addTextChangedListener(new TextWatcher() {
                        @Override
                        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                        @Override
                        public void onTextChanged(CharSequence s, int start, int before, int count) {
                            adapter.getFilter().filter(s);
                        }

                        @Override
                        public void afterTextChanged(Editable s) {}
                    });

                    // Cria o AlertDialog
                    AlertDialog dialog = new AlertDialog.Builder(getContext())
                            .setView(dialogView)
                            .create();

                    // Botão salvar
                    btnSalvar.setOnClickListener(v -> {
                        ArrayList<String> selecionadas = new ArrayList<>();
                        for (int i = 0; i < listView.getCount(); i++) {
                            if (listView.isItemChecked(i)) {
                                for (Categoria c : categoriasList) {
                                    if (adapter.getItem(i) == c.getNome()) {
                                        selecionadas.add(c.getId().toString());
                                    }
                                }
                            }
                        }

                        viewModel.categorias.setValue(selecionadas);

                        dialog.dismiss();
                    });

                    dialog.show();

                }
                else {
                    Log.e("Cadastro1Fragment", "Erro ao obter categorias: " + response.code());
                }
            }
            @Override
            public void onFailure(Call<List<Categoria>> call, Throwable t) {
                Log.e("Cadastro1Fragment", "Erro ao obter categorias", t);
            }
        });
    }

    private void mostrarDialogTags() {
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_tags, null);

        EditText etPesquisar = dialogView.findViewById(R.id.etPesquisarTags);
        ListView listView = dialogView.findViewById(R.id.listViewTags);
        Button btnSalvar = dialogView.findViewById(R.id.btnSalvarTags);

        // Lista de categorias
        Call<List<Tag>> tagsCall = RetrofitClient.getInstance().getMyApi().getTags();
        tagsCall.enqueue(new Callback<List<Tag>>() {
            @Override
            public void onResponse(Call<List<Tag>> call, Response<List<Tag>> response) {
                if (response.isSuccessful()) {
                    List<String> tags = new ArrayList<>();
                    List<Tag> tagsList = response.body();

                    if (tagsList != null) {
                        Collections.sort(tagsList, new Comparator<Tag>() {
                            @Override
                            public int compare(Tag t1, Tag t2) {
                                return t1.getNome().compareToIgnoreCase(t2.getNome());
                            }
                        });
                    }

                    for (Tag t : tagsList) {
                        tags.add(t.getNome());
                    }

                    // Adapter padrão com múltipla seleção
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(
                            getContext(),
                            android.R.layout.simple_list_item_multiple_choice,
                            tags
                    );
                    listView.setAdapter(adapter);

                    // Filtro de pesquisa
                    etPesquisar.addTextChangedListener(new TextWatcher() {
                        @Override
                        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                        @Override
                        public void onTextChanged(CharSequence s, int start, int before, int count) {
                            adapter.getFilter().filter(s);
                        }

                        @Override
                        public void afterTextChanged(Editable s) {}
                    });

                    // Cria o AlertDialog
                    AlertDialog dialog = new AlertDialog.Builder(getContext())
                            .setView(dialogView)
                            .create();

                    // Botão salvar
                    btnSalvar.setOnClickListener(v -> {
                        ArrayList<String> selecionadas = new ArrayList<>();
                        for (int i = 0; i < listView.getCount(); i++) {
                            if (listView.isItemChecked(i)) {
                                for (Tag ta : tagsList) {
                                    if (adapter.getItem(i) == ta.getNome()) {
                                        selecionadas.add(ta.getId().toString());
                                    }
                                }
                            }
                        }

                        viewModel.tags.setValue(selecionadas);

                        dialog.dismiss();
                    });

                    dialog.show();

                }
                else {
                    Log.e("Cadastro1Fragment", "Erro ao obter categorias: " + response.code());
                }
            }
            @Override
            public void onFailure(Call<List<Tag>> call, Throwable t) {
                Log.e("Cadastro1Fragment", "Erro ao obter categorias", t);
            }
        });
    }
}