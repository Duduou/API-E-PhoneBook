package com.example.e_phonebook;

import java.io.Serializable;
public class Foto implements Serializable{
    private Integer id;
    private String url;
    private Estabelecimento estabelecimento;

    public Foto(Integer id, String url, Estabelecimento estabelecimento) {
        this.id = id;
        this.url = url;
        this.estabelecimento = estabelecimento;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Estabelecimento getEstabelecimento() {
        return estabelecimento;
    }

    public void setEstabelecimento(Estabelecimento estabelecimento) {
        this.estabelecimento = estabelecimento;
    }
}
