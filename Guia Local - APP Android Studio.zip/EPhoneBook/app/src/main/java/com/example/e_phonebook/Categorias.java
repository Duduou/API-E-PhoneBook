package com.example.e_phonebook;

import java.io.Serializable;

public class Categorias implements Serializable {
    private Integer estabelecimentoID;
    private Integer categoriaID;
    private Categoria categoria;

    public Categorias(Integer estabelecimentoID, Integer categoriaID, Categoria categoria) {
        this.estabelecimentoID = estabelecimentoID;
        this.categoriaID = categoriaID;
        this.categoria = categoria;
    }

    public Integer getEstabelecimentoID() {
        return estabelecimentoID;
    }

    public void setEstabelecimentoID(Integer estabelecimentoID) {
        this.estabelecimentoID = estabelecimentoID;
    }

    public Integer getCategoriaID() {
        return categoriaID;
    }

    public void setCategoriaID(Integer categoriaID) {
        this.categoriaID = categoriaID;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }
}
