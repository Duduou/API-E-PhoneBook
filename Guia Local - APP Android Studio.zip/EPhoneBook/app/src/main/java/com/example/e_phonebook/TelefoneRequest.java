package com.example.e_phonebook;

public class TelefoneRequest {
    private String numero;

    public TelefoneRequest(String numero) {
        this.numero = numero;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }
}
