package com.example.e_phonebook;

import java.io.Serializable;
public class Email implements Serializable {
    private Integer id;
    private int estabelecimento_id;
    private String email;

    public Email(Integer id, int estabelecimento_id, String email) {
        this.id = id;
        this.estabelecimento_id = estabelecimento_id;
        this.email = email;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getEstabelecimento_id() {
        return estabelecimento_id;
    }

    public void setEstabelecimento_id(int estabelecimento_id) {
        this.estabelecimento_id = estabelecimento_id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
