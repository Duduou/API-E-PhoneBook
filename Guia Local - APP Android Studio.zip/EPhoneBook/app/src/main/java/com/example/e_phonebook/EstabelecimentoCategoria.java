package com.example.e_phonebook;

public class EstabelecimentoCategoria {
    private int id;
    private int estabelecimento_id;
    private int categoria_id;

    public EstabelecimentoCategoria(int id, int estabelecimento_id, int categoria_id) {
        this.id = id;
        this.estabelecimento_id = estabelecimento_id;
        this.categoria_id = categoria_id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEstabelecimento_id() {
        return estabelecimento_id;
    }

    public void setEstabelecimento_id(int estabelecimento_id) {
        this.estabelecimento_id = estabelecimento_id;
    }

    public int getCategoria_id() {
        return categoria_id;
    }

    public void setCategoria_id(int categoria_id) {
        this.categoria_id = categoria_id;
    }
}
