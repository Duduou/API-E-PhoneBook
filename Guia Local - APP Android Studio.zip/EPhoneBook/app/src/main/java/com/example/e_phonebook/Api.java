package com.example.e_phonebook;

import java.util.List;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface Api {
    String BASE_URL = "COLOCAR A URL DO SEU BANCO DE DADOS AQUI";

    @POST("login")
    Call<TokenResponse> login(@Body LoginRequest loginRequest);

    @POST("register")
    Call<RegisterResponse> register(@Body RegisterRequest registerRequest);

    @GET("usuarios/foto")
    Call<PhotoResponse> getFoto(@Header("Authorization") String token);

    @Multipart
    @POST("usuarios/foto")
    Call<Void> uploadFotoPerfilUsuario(@Header("Authorization") String token, @Part MultipartBody.Part arquivo);

    @GET("usuarios/nome")
    Call<NameResponse> getNome(@Header("Authorization") String token);

    @GET("usuarios/id")
    Call<IdResponse> getId(@Header("Authorization") String token);

    @GET("estabelecimentos")
    Call<List<Estabelecimento>> getEstabelecimentos();
    @GET("estabelecimentos/{id}")
    Call<Estabelecimento> getEstabelecimento(@Path("id") int id);
    @DELETE("estabelecimentos/{id}")
    Call<Void> deletarEstabelecimento(@Path("id") int id, @Header("Authorization") String token);

    @GET("/buscar")
    Call<List<Estabelecimento>> getEstabelecimentosByNameQuery(@Query("term") String q);

    @POST("estabelecimentos")
    Call<Estabelecimento> createEstabelecimento(@Body CadastroEstabelecimentoRequest estabelecimento, @Header("Authorization") String token);

    @PUT("estabelecimentos/{id}")
    Call<Estabelecimento> editEstabelecimento(@Path("id") int id, @Body CadastroEstabelecimentoRequest estabelecimento, @Header("Authorization") String token);

    @GET("favoritos")
    Call<List<Estabelecimento>> getFavoritos(@Header("Authorization") String token);

    @POST("favoritos/{id}")
    Call<Favorito> adicionarFavorito(@Path("id") int id, @Header("Authorization") String token);

    @DELETE("favoritos/{id}")
    Call<Void> removerFavorito(@Path("id") int id, @Header("Authorization") String token);

    @GET("categorias")
    Call<List<Categoria>> getCategorias();

    @POST("estabelecimentos/{id}/categorias")
    Call<Void> registrarCategoriasEstabelecimento(@Path("id") int id, @Header("Authorization") String token, @Body CategoriasRequest categorias);
    @DELETE("estabelecimentos/{id}/categorias/{categoriaId}")
    Call<Void> removerCategoriaEstabelecimento(@Path("id") int id, @Header("Authorization") String token, @Path("categoriaId") int categoriaId);
    @GET("tags")
    Call<List<Tag>> getTags();
    @POST("estabelecimentos/{id}/tags")
    Call<Void> registrarTagsEstabelecimento(@Path("id") int id, @Header("Authorization") String token, @Body TagsRequest tags);
    @DELETE("estabelecimentos/{id}/tags/{tagId}")
    Call<Void> removerTagEstabelecimento(@Path("id") int id, @Header("Authorization") String token, @Path("tagId") int tagId);

    @Multipart
    @POST("estabelecimentos/{id}/foto-perfil")
    Call<Void> uploadFotoPerfilEstabelecimento(@Path("id") int id, @Header("Authorization") String token, @Part MultipartBody.Part arquivo);

    @Multipart
    @POST("estabelecimentos/{id}/fotos/upload")
    Call<Void> uploadFotosEstabelecimento(@Path("id") int id, @Header("Authorization") String token, @Part MultipartBody.Part arquivo);

    @POST("estabelecimentos/{id}/telefones")
    Call<Void> registrarTelefoneEstabelecimento(@Path("id") int id, @Header("Authorization") String token, @Body TelefoneRequest telefone);

    @POST("estabelecimentos/{id}/emails")
    Call<Void> registrarEmailEstabelecimento(@Path("id") int id, @Header("Authorization") String token, @Body EmailRequest email);

    @DELETE("telefones/{id}")
    Call<Void> deletarTelefoneEstabelecimento(@Path("id") int id, @Header("Authorization") String token);

    @DELETE("emails/{id}")
    Call<Void> deletarEmailEstabelecimento(@Path("id") int id, @Header("Authorization") String token);

    @DELETE("fotos/{id}")
    Call<Void> deletarFotosEstabelecimento(@Path("id") int id, @Header("Authorization") String token);

    @POST("estabelecimentos/{id}/horario")
    Call<Void> registrarHorarioEstabelecimento(@Path("id") int id, @Header("Authorization") String token, @Body HorarioRequest horario);

    @PUT("estabelecimentos/{id}/horario")
    Call<Void> atualizarHorarioEstabelecimento(@Path("id") int id, @Header("Authorization") String token, @Body HorarioRequest horario);
}