package com.example.e_phonebook;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.room.Room;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.IOException;
import java.util.List;
import java.util.function.Consumer;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        String DATABASE_NAME = "E-PhoneBook-DB";

        AppDatabase db = Room.databaseBuilder(getApplicationContext(),
                AppDatabase.class, DATABASE_NAME)
                .fallbackToDestructiveMigration()
                .allowMainThreadQueries()
                .build();

        LoginDAO loginDAO = db.loginDAO();

        LoginEntity saved = loginDAO.getSavedLogin();

        if (saved != null) {
            String email = saved.email;
            String senha = saved.senha;
            Log.d("TESTE", email);
            Log.d("TESTE", senha);
        }
        else {
            Intent itLogin = new Intent(this, LoginActivity.class);
            startActivity(itLogin);

        }

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);

        Fragment searchFragment = new SearchFragment();
        Fragment categoryFragment = new CategoryFragment();
        Fragment favoriteFragment = new FavoriteFragment();
        Fragment profileFragment = new ProfileFragment();

        trocaFragmento(searchFragment);

        bottomNavigationView.setOnItemSelectedListener(new BottomNavigationView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                atualizarFavoritos();
                if (item.getItemId() == R.id.search) {
                    trocaFragmento(searchFragment);
                }

                if (item.getItemId() == R.id.category) {
                    trocaFragmento(categoryFragment);
                }

                if (item.getItemId() == R.id.favorites) {
                    trocaFragmento(favoriteFragment);
                }

                if (item.getItemId() == R.id.profile) {
                    trocaFragmento(profileFragment);
                }
                return true;
            }
        });

    }

    private void trocaFragmento(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.flFragment, fragment)
                .commit();
        atualizarFavoritos();
    }

    private void atualizarFavoritos() {
        String DATABASE_NAME = "E-PhoneBook-DB";
        AppDatabase db = Room.databaseBuilder(getApplicationContext(),
                        AppDatabase.class, DATABASE_NAME)
                .fallbackToDestructiveMigration()
                .allowMainThreadQueries()
                .build();

        LoginDAO loginDAO = db.loginDAO();

        LoginEntity saved = loginDAO.getSavedLogin();
        LoginRequest loginRequest = new LoginRequest(saved.email, saved.senha);

        Call<TokenResponse> tokenCall = RetrofitClient.getInstance().getMyApi().login(loginRequest);
        tokenCall.enqueue(new Callback<TokenResponse>() {
            @Override
            public void onResponse(Call<TokenResponse> call, Response<TokenResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    String token = response.body().getToken();
                    Call<List<Estabelecimento>> favoritosCall = RetrofitClient.getInstance().getMyApi().getFavoritos(token);
                    favoritosCall.enqueue(new Callback<List<Estabelecimento>>() {
                        @Override
                        public void onResponse(Call<List<Estabelecimento>> call, Response<List<Estabelecimento>> response) {
                            if (response.isSuccessful() && response.body() != null) {
                                List<Estabelecimento> favoritos = response.body();

                            } else {
                                Toast.makeText(getApplicationContext(), "Erro na resposta da API.", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<List<Estabelecimento>> call, Throwable t) {
                            Toast.makeText(getApplicationContext(), "Erro: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    Toast.makeText(getApplicationContext(), "Erro na resposta da API.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<TokenResponse> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "Erro: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}