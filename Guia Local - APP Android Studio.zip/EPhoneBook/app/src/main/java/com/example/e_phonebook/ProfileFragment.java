package com.example.e_phonebook;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ProfileFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ProfileFragment extends Fragment {

    private int userId;
    private Intent itLogin;
    private ImageView ivFotoUsuario;
    private ActivityResultLauncher<Intent> fotoPerfilLauncher;

    private  String token;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public ProfileFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment ProfileFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ProfileFragment newInstance(String param1, String param2) {
        ProfileFragment fragment = new ProfileFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Button btnLogout = getView().findViewById(R.id.btnLogout);
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String DATABASE_NAME = "E-PhoneBook-DB";

                AppDatabase db = Room.databaseBuilder(getContext(),
                                AppDatabase.class, DATABASE_NAME).
                        fallbackToDestructiveMigration()
                        .allowMainThreadQueries()
                        .build();

                LoginDAO loginDAO = db.loginDAO();
                loginDAO.deleteAll();

                startActivity(itLogin);
            }
        });
        ivFotoUsuario = getView().findViewById(R.id.ivFotoUsuario);
        carregarInfosUsuario();
        itLogin = new Intent(getContext(), LoginActivity.class);
        Button btnNovoEstabelecimento = getView().findViewById(R.id.btnNovoEstabelecimento);
        btnNovoEstabelecimento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cadastro1Fragment cadastro1Fragment = new Cadastro1Fragment();
                getParentFragmentManager()
                        .beginTransaction()
                        .replace(R.id.flFragment, cadastro1Fragment)
                        .addToBackStack(null)
                        .commit();
            }
        });

        fotoPerfilLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        Uri uri = result.getData().getData();

                        Picasso.get()
                                .load(uri)
                                .resize(200, 200)
                                .centerCrop()
                                .into(ivFotoUsuario);

                        File file = getFileFromUri(uri);
                        RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), file);
                        MultipartBody.Part arquivoPart = MultipartBody.Part.createFormData("arquivo", file.getName(), requestFile);
                        Call<Void> uploadFotoPerfilUsuario = RetrofitClient.getInstance().getMyApi().uploadFotoPerfilUsuario(token, arquivoPart);
                        uploadFotoPerfilUsuario.enqueue(new Callback<Void>() {
                            @Override
                            public void onResponse(Call<Void> call, Response<Void> response) {
                                if (response.isSuccessful()) {

                                } else {
                                    Toast.makeText(getContext(), "Erro: " + response.code(), Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onFailure(Call<Void> call, Throwable t) {
                                Toast.makeText(getContext(), "Erro: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });

        ivFotoUsuario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                fotoPerfilLauncher.launch(Intent.createChooser(intent, "Selecione a foto de perfil"));
            }
        });
    }

    public void carregarInfosUsuario() {
        String DATABASE_NAME = "E-PhoneBook-DB";
        AppDatabase db = Room.databaseBuilder(getContext(),
                AppDatabase.class, DATABASE_NAME)
                .fallbackToDestructiveMigration()
                .allowMainThreadQueries()
                .build();

        LoginDAO loginDAO = db.loginDAO();

        LoginEntity saved = loginDAO.getSavedLogin();
        LoginRequest loginRequest = new LoginRequest(saved.email, saved.senha);

        Call<TokenResponse> tokenCall = RetrofitClient.getInstance().getMyApi().login(loginRequest);
        tokenCall.enqueue(new Callback<TokenResponse>() {
            @Override
            public void onResponse(Call<TokenResponse> call, Response<TokenResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    token = response.body().getToken();

                    Call<IdResponse> idCall = RetrofitClient.getInstance().getMyApi().getId(token);
                    idCall.enqueue(new Callback<IdResponse>() {
                      @Override
                      public void onResponse(Call<IdResponse> call, Response<IdResponse> response) {
                          if (response.isSuccessful() && response.body() != null) {
                              IdResponse idResponse = response.body();
                              userId = idResponse.getId();
                          }
                      }
                      @Override
                      public void onFailure(Call<IdResponse> call, Throwable t) {
                          Toast.makeText(getContext(), "Erro: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                      }
                   });

                    Call<PhotoResponse> fotoCall = RetrofitClient.getInstance().getMyApi().getFoto(token);
                    fotoCall.enqueue(new Callback<PhotoResponse>() {
                        @Override
                        public void onResponse(Call<PhotoResponse> call, Response<PhotoResponse> response) {
                            if (response.isSuccessful() && response.body() != null) {
                                PhotoResponse photoResponse = response.body();
                                Picasso.get()
                                        .load(photoResponse.getFoto())
                                        .resize(200, 200)
                                        .centerCrop()
                                        .into(ivFotoUsuario);
                            }
                            else {
                                Picasso.get()
                                        .load(R.drawable.user)
                                        .resize(200, 200)
                                        .centerCrop()
                                        .into(ivFotoUsuario);
                            }
                        }
                        @Override
                        public void onFailure(Call<PhotoResponse> call, Throwable t) {
                            Toast.makeText(getContext(), "Erro: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });

                    Call<NameResponse> nomeCall = RetrofitClient.getInstance().getMyApi().getNome(token);
                    nomeCall.enqueue(new Callback<NameResponse>() {
                        @Override
                        public void onResponse(Call<NameResponse> call, Response<NameResponse> response) {
                            if (response.isSuccessful() && response.body() != null) {
                                NameResponse nameResponse = response.body();
                                TextView txtNomeUsuario = getView().findViewById(R.id.txtNomeUsuario);
                                txtNomeUsuario.setText(nameResponse.getNome());
                            }
                        }
                        @Override
                        public void onFailure(Call<NameResponse> call, Throwable t) {
                            Toast.makeText(getContext(), "Erro: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });

                    Call<List<Estabelecimento>> favoritosCall = RetrofitClient.getInstance().getMyApi().getFavoritos(token);
                    favoritosCall.enqueue(new Callback<List<Estabelecimento>>() {
                        @Override
                        public void onResponse(Call<List<Estabelecimento>> call, Response<List<Estabelecimento>> response) {
                            if (response.isSuccessful() && response.body() != null) {
                                List<Estabelecimento> favoritos = response.body();
                                TextView txtContadorFavoritosUsuario = getView().findViewById(R.id.txtContadorFavoritosUsuario);
                                txtContadorFavoritosUsuario.setText(favoritos.size() + " Estabelecimentos Favoritados");

                            }
                        }
                        @Override
                        public void onFailure(Call<List<Estabelecimento>> call, Throwable t) {
                            Toast.makeText(getContext(), "Erro: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });

                    Call<List<Estabelecimento>> cadastradosCall = RetrofitClient.getInstance().getMyApi().getEstabelecimentos();
                    cadastradosCall.enqueue(new Callback<List<Estabelecimento>>() {
                        @Override
                        public void onResponse(Call<List<Estabelecimento>> call, Response<List<Estabelecimento>> response) {
                            if (response.isSuccessful() && response.body() != null) {

                                List<Estabelecimento> cadastrados = response.body();
                                List<Estabelecimento> filtrados = new ArrayList<>();
                                for (Estabelecimento e : cadastrados) {
                                    if (e.getUsuario() != null) {
                                        if (e.getUsuario().getId() == userId) {
                                            filtrados.add(e);
                                        }
                                    }
                                }

                                if (filtrados != null) {
                                    Collections.sort(filtrados, new Comparator<Estabelecimento>() {
                                        @Override
                                        public int compare(Estabelecimento e1, Estabelecimento e2) {
                                            return e1.getNome().compareToIgnoreCase(e2.getNome());
                                        }
                                    });
                                }

                                TextView txtContadorCadastrosUsuario = getView().findViewById(R.id.txtContadorCadastrosUsuario);
                                txtContadorCadastrosUsuario.setText(filtrados.size() + " Estabelecimentos Cadastrados");

                                RecyclerView rvEstabelecimentosUsuario = getView().findViewById(R.id.rvEstabelecimentosUsuario);
                                MeuAdaptador.OnItemClickListener listener = estabelecimento -> {
                                    Cadastro1Fragment cadastro1FragmentEdit = Cadastro1Fragment.newInstance(true, estabelecimento);

                                    getParentFragmentManager()
                                            .beginTransaction()
                                            .replace(R.id.flFragment, cadastro1FragmentEdit)
                                            .addToBackStack(null)
                                            .commit();
                                };

                                MeuAdaptador adaptador = new MeuAdaptador(filtrados, listener);

                                RecyclerView.LayoutManager layout =
                                        new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);
                                rvEstabelecimentosUsuario.setLayoutManager(layout);
                                rvEstabelecimentosUsuario.setAdapter(adaptador);
                            }
                        }

                        @Override
                        public void onFailure(Call<List<Estabelecimento>> call, Throwable t) {
                            Toast.makeText(getContext(), "Erro: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });

                }
                else {
                    Toast.makeText(getContext(), "Erro na resposta da API.", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onFailure(Call<TokenResponse> call, Throwable t) {
                Toast.makeText(getContext(), "Erro: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private File getFileFromUri(Uri uri) {
        String path = RealPathUtil.getRealPath(requireContext(), uri);
        return new File(path);
    }
}