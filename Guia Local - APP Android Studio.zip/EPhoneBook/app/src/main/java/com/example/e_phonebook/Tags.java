package com.example.e_phonebook;

import java.io.Serializable;

public class Tags implements Serializable {
    private Integer estabelecimentoID;
    private Integer tagID;
    private Categoria tag;

    public Tags(Integer estabelecimentoID, Integer tagID, Categoria tag) {
        this.estabelecimentoID = estabelecimentoID;
        this.tagID = tagID;
        this.tag = tag;
    }

    public Integer getEstabelecimentoID() {
        return estabelecimentoID;
    }

    public void setEstabelecimentoID(Integer estabelecimentoID) {
        this.estabelecimentoID = estabelecimentoID;
    }

    public Integer getTagID() {
        return tagID;
    }

    public void setTagID(Integer tagID) {
        this.tagID = tagID;
    }

    public Categoria getTag() {
        return tag;
    }

    public void setTag(Categoria tag) {
        this.tag = tag;
    }
}

