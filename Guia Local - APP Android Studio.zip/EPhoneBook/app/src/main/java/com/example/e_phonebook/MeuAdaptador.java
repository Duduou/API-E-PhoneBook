package com.example.e_phonebook;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class MeuAdaptador extends RecyclerView.Adapter<MeuAdaptador.ViewHolder> {
    private List<Estabelecimento> estabelecimentos;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Estabelecimento estabelecimento);
    }

    public MeuAdaptador(List<Estabelecimento> estabelecimentos, OnItemClickListener listener) {
        this.estabelecimentos = (estabelecimentos != null) ? estabelecimentos : new ArrayList<>();
        this.listener = listener;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView txtEstabelecimentoNome;
        final TextView txtEstabelecimentoDescricao;
        final TextView txtEstabelecimentoCategoria;
        final ImageView ivEstabelecimentoFoto;

        public ViewHolder(View view) {
            super(view);
            txtEstabelecimentoNome = view.findViewById(R.id.txtEstabelecimentoNome);
            txtEstabelecimentoDescricao = view.findViewById(R.id.txtEstabelecimentoDescricao);
            ivEstabelecimentoFoto = view.findViewById(R.id.ivEstabelecimentoFoto);
            txtEstabelecimentoCategoria = view.findViewById(R.id.txtEstabelecimentoCategoria);
        }

        public void bind(Estabelecimento est, OnItemClickListener listener) {
            itemView.setOnClickListener(v -> {
                if (listener != null && getAdapterPosition() != RecyclerView.NO_POSITION) {
                    listener.onItemClick(est);
                }
            });
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_estabelecimento, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Estabelecimento estabelecimento = estabelecimentos.get(position);
        holder.txtEstabelecimentoNome.setText(estabelecimento.getNome());
        holder.txtEstabelecimentoDescricao.setText(estabelecimento.getDescricao());
        List<Categorias> categorias = estabelecimento.getCategorias();

        if (categorias != null && !categorias.isEmpty()) {
            if (categorias.size() >= 2) {
                holder.txtEstabelecimentoCategoria.setText(
                        categorias.get(0).getCategoria().getNome() + ", " + categorias.get(1).getCategoria().getNome()
                );
            } else {
                holder.txtEstabelecimentoCategoria.setText(
                        categorias.get(0).getCategoria().getNome()
                );
            }
        } else {
            holder.txtEstabelecimentoCategoria.setText("Sem categoria");
        }

        Picasso.get()
                .load(estabelecimento.getFotoPerfil())
                .resize(200, 200)
                .centerCrop()
                .into(holder.ivEstabelecimentoFoto);

        holder.bind(estabelecimento, listener);
    }

    @Override
    public int getItemCount() {
        return (estabelecimentos != null) ? estabelecimentos.size() : 0;
    }
}
