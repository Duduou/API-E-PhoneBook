package com.example.e_phonebook;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.room.Room;

import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link DetailFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class DetailFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_ESTABELECIMENTO = "estabelecimento";

    // TODO: Rename and change types of parameters
    private Estabelecimento mEstabelecimento;

    public DetailFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param estabelecimento Parameter 1.
     * @return A new instance of fragment DetailFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static DetailFragment newInstance(Estabelecimento estabelecimento) {
        DetailFragment fragment = new DetailFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_ESTABELECIMENTO, estabelecimento);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mEstabelecimento = (Estabelecimento) getArguments().getSerializable(ARG_ESTABELECIMENTO);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_detail, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageView ivFotoEstabelecimento;
        TextView txtNomeEstabelecimento;
        TextView txtTelefoneEstabelecimento;
        TextView txtEmailEstabelecimento;
        TextView txtCategoriasEstabelecimento;
        LinearLayout llFotosEstabelecimento;
        TextView txtHorariosEstabelecimento;
        ImageButton btnWhatsapp;
        ImageButton btnInstagram;
        ImageButton btnFacebook;
        ImageButton btnFavoritarEstabelecimento;
        ivFotoEstabelecimento = view.findViewById(R.id.ivFotoEstabelecimento);
        txtNomeEstabelecimento = view.findViewById(R.id.txtNomeEstabelecimento);
        txtTelefoneEstabelecimento = view.findViewById(R.id.txtTelefoneEstabelecimento);
        txtEmailEstabelecimento = view.findViewById(R.id.txtEmailEstabelecimento);
        txtCategoriasEstabelecimento = view.findViewById(R.id.txtCategoriasEstabelecimento);
        btnFavoritarEstabelecimento = view.findViewById(R.id.btnFavoritarEstabelecimento);
        llFotosEstabelecimento = view.findViewById(R.id.llFotosEstabelecimento);
        txtHorariosEstabelecimento = view.findViewById(R.id.txtHorariosEstabelecimento);
        btnWhatsapp = view.findViewById(R.id.btnWhatsapp);
        btnInstagram = view.findViewById(R.id.btnInstagram);
        btnFacebook = view.findViewById(R.id.btnFacebook);

        atualizarIcone();

        List<Categorias> categorias = mEstabelecimento.getCategorias();
        if (categorias == null) categorias = new ArrayList<>();

        if (categorias.size() >= 2) {
            txtCategoriasEstabelecimento.setText(categorias.get(0).getCategoria().getNome() + ", " + categorias.get(1).getCategoria().getNome());
        } else if (categorias.size() > 0) {
            txtCategoriasEstabelecimento.setText(categorias.get(0).getCategoria().getNome());
        } else {
            txtCategoriasEstabelecimento.setText("Sem categoria");
        }

        Picasso.get()
                .load(mEstabelecimento.getFotoPerfil())
                .resize(200, 200)
                .centerCrop()
                .into(ivFotoEstabelecimento);
        txtNomeEstabelecimento.setText(mEstabelecimento.getNome());

        if (mEstabelecimento.getTelefones() == null) {
            txtTelefoneEstabelecimento.setText("Sem Telefones");
        }
        else if (mEstabelecimento.getTelefones().size() > 1) {
            txtTelefoneEstabelecimento.setText("Telefone: " + mEstabelecimento.getTelefones().get(0).getNumero() + ", " + mEstabelecimento.getTelefones().get(1).getNumero());
        }
        else if (mEstabelecimento.getTelefones().size() > 0) {
            txtTelefoneEstabelecimento.setText("Telefone: " + mEstabelecimento.getTelefones().get(0).getNumero());
        }
        else {
            txtTelefoneEstabelecimento.setText("Sem Telefones");
        }

        if (mEstabelecimento.getEmails() == null) {
            txtEmailEstabelecimento.setText("Sem Emails");
        }
        else if (mEstabelecimento.getEmails().size() > 1) {
            txtEmailEstabelecimento.setText("Email: " + mEstabelecimento.getEmails().get(0).getEmail() + ", " + mEstabelecimento.getEmails().get(1).getEmail());
        }
        else if (mEstabelecimento.getEmails().size() > 0) {
            txtEmailEstabelecimento.setText("Email: " + mEstabelecimento.getEmails().get(0).getEmail());
        }
        else {
            txtEmailEstabelecimento.setText("Sem Emails");
        }

        btnFavoritarEstabelecimento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                favoritar();
            }
        });
        btnWhatsapp.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               if(mEstabelecimento.getWhatsapp() != null && !mEstabelecimento.getWhatsapp().isEmpty()) {
                   Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=" + mEstabelecimento.getWhatsapp()));
                   startActivity(intent);
               }
               else {
                   Toast.makeText(getContext(), "Sem Whatsapp", Toast.LENGTH_SHORT).show();
               }
           }
        });
        btnInstagram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mEstabelecimento.getInstagram() != null && !mEstabelecimento.getInstagram().isEmpty()) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/" + mEstabelecimento.getInstagram()));
                    startActivity(intent);
                }
                else {
                    Toast.makeText(getContext(), "Sem Instagram", Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnFacebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mEstabelecimento.getFacebook() != null && !mEstabelecimento.getFacebook().isEmpty()) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/" +mEstabelecimento.getFacebook()));
                    startActivity(intent);
                }
                else {
                    Toast.makeText(getContext(), "Sem Facebook", Toast.LENGTH_SHORT).show();
                }
            }
        });

        String horarios;
        String hDom;
        String hSeg;
        String hTer;
        String hQua;
        String hQui;
        String hSex;
        String hSab;

        if (mEstabelecimento.getHorario().getDom().isEmpty() || mEstabelecimento.getHorario().getDom() == null) {
            hDom = "Dom: Não informado";
        }
        else {
            hDom = "Dom: " + mEstabelecimento.getHorario().getDom();
        }

        if (mEstabelecimento.getHorario().getSeg().isEmpty() || mEstabelecimento.getHorario().getSeg() == null) {
            hSeg = "Seg: Não informado";
        }
        else {
            hSeg = "Seg: " + mEstabelecimento.getHorario().getSeg();
        }

        if (mEstabelecimento.getHorario().getTer().isEmpty() || mEstabelecimento.getHorario().getTer() == null) {
            hTer = "Ter: Não informado";
        }
        else {
            hTer = "Ter: " + mEstabelecimento.getHorario().getTer();
        }

        if (mEstabelecimento.getHorario().getQua().isEmpty() || mEstabelecimento.getHorario().getQua() == null) {
            hQua = "Qua: Não informado";
        }
        else {
            hQua = "Qua: " + mEstabelecimento.getHorario().getQua();
        }

        if (mEstabelecimento.getHorario().getQui().isEmpty() || mEstabelecimento.getHorario().getQui() == null) {
            hQui = "Qui: Não informado";
        }
        else {
            hQui = "Qui: " + mEstabelecimento.getHorario().getQui();
        }

        if (mEstabelecimento.getHorario().getSex().isEmpty() || mEstabelecimento.getHorario().getSex() == null) {
            hSex = "Sex: Não informado";
        }
        else {
            hSex = "Sex: " + mEstabelecimento.getHorario().getSex();
        }

        if (mEstabelecimento.getHorario().getSab().isEmpty() || mEstabelecimento.getHorario().getSab() == null) {
            hSab = "Sab: Não informado";
        }
        else {
            hSab = "Sab: " + mEstabelecimento.getHorario().getSab();
        }

        horarios =
                hDom + "\n" +
                hSeg + "\n" +
                hTer + "\n" +
                hQua + "\n" +
                hQui + "\n" +
                hSex + "\n" +
                hSab;


        txtHorariosEstabelecimento.setText(horarios);

        if (mEstabelecimento.getFotos() != null) {
            for (Foto foto : mEstabelecimento.getFotos()) {
                String url = foto.getUrl();

                ImageView imageView = new ImageView(getContext());

                // Define altura fixa e largura WRAP_CONTENT
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 200, getResources().getDisplayMetrics())
                );
                params.setMargins(16, 16, 16, 16);
                imageView.setLayoutParams(params);
                imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);


                Picasso.get()
                        .load(url)
                        .resize(0, 500)
                        .onlyScaleDown()
                        .into(imageView);

                llFotosEstabelecimento.addView(imageView);
            }
        }

        SupportMapFragment mapFragment = new SupportMapFragment();
        getChildFragmentManager()
                .beginTransaction()
                .replace(R.id.flMapaEstabelecimento, mapFragment)
                .commit();

        mapFragment.getMapAsync(googleMap -> {
            LatLng coordenada = new LatLng(
                    mEstabelecimento.getLongitude(),
                    mEstabelecimento.getLatitude()
            );

            googleMap.addMarker(new MarkerOptions().position(coordenada).title("Local"));
            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(coordenada, 15));
        });
    }

    private void favoritar() {
        String DATABASE_NAME = "E-PhoneBook-DB";
        AppDatabase db = Room.databaseBuilder(getContext(),
                        AppDatabase.class, DATABASE_NAME)
                .fallbackToDestructiveMigration()
                .allowMainThreadQueries()
                .build();

        LoginDAO loginDAO = db.loginDAO();

        LoginEntity saved = loginDAO.getSavedLogin();
        LoginRequest loginRequest = new LoginRequest(saved.email, saved.senha);

        Call<TokenResponse> tokenCall = RetrofitClient.getInstance().getMyApi().login(loginRequest);
        tokenCall.enqueue(new Callback<TokenResponse>() {
            @Override
            public void onResponse(Call<TokenResponse> call, Response<TokenResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    String token = response.body().getToken();

                    Call<List<Estabelecimento>> favoritosCall = RetrofitClient.getInstance().getMyApi().getFavoritos(token);
                    favoritosCall.enqueue(new Callback<List<Estabelecimento>>() {
                        private boolean favoritado = false;

                        @Override
                        public void onResponse(Call<List<Estabelecimento>> call, Response<List<Estabelecimento>> response) {
                            if (response.isSuccessful() && response.body() != null) {
                                List<Estabelecimento> favoritos = response.body();
                                for (Estabelecimento estabelecimento : favoritos) {
                                    if (estabelecimento.getId().equals(mEstabelecimento.getId())) {
                                        //Já favoritado
                                        ImageButton btnFavoritarEstabelecimento = getView().findViewById(R.id.btnFavoritarEstabelecimento);
                                        btnFavoritarEstabelecimento.setImageResource(R.drawable.heart_full);
                                        favoritado = true;
                                    }
                                }
                                if (favoritado){
                                    Call<Void> favoritarCall = RetrofitClient.getInstance().getMyApi().removerFavorito(mEstabelecimento.getId(), token);
                                    favoritarCall.enqueue(new Callback<Void>() {
                                        @Override
                                        public void onResponse(Call<Void> call, Response<Void> response) {
                                            if (response.isSuccessful()) {
                                                View view = getView();
                                                if (view != null) {
                                                    ImageButton btnFavoritarEstabelecimento = view.findViewById(R.id.btnFavoritarEstabelecimento);
                                                    btnFavoritarEstabelecimento.setImageResource(R.drawable.heart);
                                                }
                                            } else {
                                                Toast.makeText(getContext(), "Erro na resposta da API.", Toast.LENGTH_SHORT).show();
                                            }
                                        }

                                        @Override
                                        public void onFailure(Call<Void> call, Throwable t) {
                                            Toast.makeText(getContext(), "Erro: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                }
                                else {
                                    Call<Favorito> favoritarCall = RetrofitClient.getInstance().getMyApi().adicionarFavorito(mEstabelecimento.getId(), token);
                                    favoritarCall.enqueue(new Callback<Favorito>() {
                                        @Override
                                        public void onResponse(Call<Favorito> call, Response<Favorito> response) {
                                            if (response.isSuccessful() && response.body() != null) {
                                                View view = getView();
                                                if (view != null) {
                                                    ImageButton btnFavoritarEstabelecimento = view.findViewById(R.id.btnFavoritarEstabelecimento);
                                                    btnFavoritarEstabelecimento.setImageResource(R.drawable.heart_full);
                                                }
                                            } else {
                                                Toast.makeText(getContext(), "Erro na resposta da API.", Toast.LENGTH_SHORT).show();
                                            }
                                        }

                                        @Override
                                        public void onFailure(Call<Favorito> call, Throwable t) {
                                            Toast.makeText(getContext(), "Erro: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                }
                            }
                            else {
                                Toast.makeText(getContext(), "Erro na resposta da API.", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<List<Estabelecimento>> call, Throwable t) {
                            Toast.makeText(getContext(), "Erro: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    Toast.makeText(getContext(), "Erro na resposta da API.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<TokenResponse> call, Throwable t) {
                Toast.makeText(getContext(), "Erro: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void atualizarIcone() {
        String DATABASE_NAME = "E-PhoneBook-DB";
        AppDatabase db = Room.databaseBuilder(getContext(),
                        AppDatabase.class, DATABASE_NAME)
                .fallbackToDestructiveMigration()
                .allowMainThreadQueries()
                .build();

        LoginDAO loginDAO = db.loginDAO();

        LoginEntity saved = loginDAO.getSavedLogin();
        LoginRequest loginRequest = new LoginRequest(saved.email, saved.senha);

        Call<TokenResponse> tokenCall = RetrofitClient.getInstance().getMyApi().login(loginRequest);
        tokenCall.enqueue(new Callback<TokenResponse>() {
            @Override
            public void onResponse(Call<TokenResponse> call, Response<TokenResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    String token = response.body().getToken();
                    Call<List<Estabelecimento>> favoritosCall = RetrofitClient.getInstance().getMyApi().getFavoritos(token);
                    favoritosCall.enqueue(new Callback<List<Estabelecimento>>() {
                        @Override
                        public void onResponse(Call<List<Estabelecimento>> call, Response<List<Estabelecimento>> response) {
                            if (response.isSuccessful() && response.body() != null) {
                                List<Estabelecimento> favoritos = response.body();

                                boolean favoritado = false;
                                for (Estabelecimento estabelecimento : favoritos) {
                                    if (estabelecimento.getId().equals(mEstabelecimento.getId())) {
                                        favoritado = true;
                                        break;
                                    }
                                }

                                View view = getView();
                                if (view != null) {
                                    ImageButton btnFavoritarEstabelecimento = view.findViewById(R.id.btnFavoritarEstabelecimento);
                                    if (favoritado) {
                                        btnFavoritarEstabelecimento.setImageResource(R.drawable.heart_full);
                                    } else {
                                        btnFavoritarEstabelecimento.setImageResource(R.drawable.heart);
                                    }
                                }

                            } else {
                                Toast.makeText(getContext(), "Erro na resposta da API.", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<List<Estabelecimento>> call, Throwable t) {
                            Toast.makeText(getContext(), "Erro: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    Toast.makeText(getContext(), "Erro na resposta da API.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<TokenResponse> call, Throwable t) {
                Toast.makeText(getContext(), "Erro: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}