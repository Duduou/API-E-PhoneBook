package com.example.e_phonebook;

public class Favorito{
    private Integer usuarioId;
    private Integer estabelecimentoId;

    public Favorito(Integer usuarioId, Integer estabelecimentoId) {
        this.usuarioId = usuarioId;
        this.estabelecimentoId = estabelecimentoId;
    }

    public Integer getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Integer usuarioId) {
        this.usuarioId = usuarioId;
    }

    public Integer getEstabelecimentoId() {
        return estabelecimentoId;
    }

    public void setEstabelecimentoId(Integer estabelecimentoId) {
        this.estabelecimentoId = estabelecimentoId;
    }
}
