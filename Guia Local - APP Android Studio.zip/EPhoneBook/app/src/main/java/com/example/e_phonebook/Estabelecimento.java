package com.example.e_phonebook;

import java.io.Serializable;
import java.util.List;


public class Estabelecimento implements Serializable {

    private Integer id;
    private String nome;
    private String descricao;
    private String endereco;
    private Double latitude;
    private Double longitude;
    private String whatsapp;
    private String facebook;
    private String instagram;
    private List<Telefone> telefones;
    private List<Email> emails;
    private List<Categorias> categorias;
    private List<Tags> tags;
    private Horario horario;
    private String fotoPerfil;
    private List<Foto> fotos;

    private Usuario usuario;

    public Estabelecimento(Integer id, String nome, String descricao, String endereco, Double longitude, Double latitude, String whatsapp, String facebook, String instagram, List<Telefone> telefones, List<Email> emails, List<Categorias> categorias, List<Tags> tags, Horario horario, String fotoPerfil, List<Foto> fotos, Usuario usuario) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
        this.endereco = endereco;
        this.longitude = longitude;
        this.latitude = latitude;
        this.whatsapp = whatsapp;
        this.facebook = facebook;
        this.instagram = instagram;
        this.telefones = telefones;
        this.emails = emails;
        this.categorias = categorias;
        this.tags = tags;
        this.horario = horario;
        this.fotoPerfil = fotoPerfil;
        this.fotos = fotos;
        this.usuario = usuario;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public String getWhatsapp() {
        return whatsapp;
    }

    public void setWhatsapp(String whatsapp) {
        this.whatsapp = whatsapp;
    }

    public String getFacebook() {
        return facebook;
    }

    public void setFacebook(String facebook) {
        this.facebook = facebook;
    }

    public String getInstagram() {
        return instagram;
    }

    public void setInstagram(String instagram) {
        this.instagram = instagram;
    }

    public List<Telefone> getTelefones() {
        return telefones;
    }

    public void setTelefones(List<Telefone> telefones) {
        this.telefones = telefones;
    }

    public List<Email> getEmails() {
        return emails;
    }

    public void setEmails(List<Email> emails) {
        this.emails = emails;
    }

    public List<Categorias> getCategorias() {
        return categorias;
    }

    public void setCategorias(List<Categorias> categorias) {
        this.categorias = categorias;
    }

    public List<Tags> getTags() {
        return tags;
    }

    public void setTags(List<Tags> tags) {
        this.tags = tags;
    }

    public Horario getHorario() { return horario; }

    public void setHorario(Horario horario) { this.horario = horario; }

    public String getFotoPerfil() { return fotoPerfil; }

    public void setFotoPerfil(String foto) { this.fotoPerfil = foto; }

    public List<Foto> getFotos() { return fotos; }

    public void setFotos(List<Foto> fotos) { this.fotos = fotos; }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
}