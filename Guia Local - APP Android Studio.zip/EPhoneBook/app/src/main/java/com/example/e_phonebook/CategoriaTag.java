package com.example.e_phonebook;

public class CategoriaTag {
    private Integer id;
    private int categoria_id;
    private int tag_id;

    public CategoriaTag(Integer id, int categoria_id, int tag_id) {
        this.id = id;
        this.categoria_id = categoria_id;
        this.tag_id = tag_id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getCategoria_id() {
        return categoria_id;
    }

    public void setCategoria_id(int categoria_id) {
        this.categoria_id = categoria_id;
    }

    public int getTag_id() {
        return tag_id;
    }

    public void setTag_id(int tag_id) {
        this.tag_id = tag_id;
    }
}
