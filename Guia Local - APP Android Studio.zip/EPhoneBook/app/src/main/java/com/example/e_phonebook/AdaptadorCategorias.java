package com.example.e_phonebook;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdaptadorCategorias extends RecyclerView.Adapter<AdaptadorCategorias.ViewHolder> {
    private final List<Categoria> categorias;
    private final OnCategoriaClickListener listener;
    public interface OnCategoriaClickListener {
        void onCategoriaClick(Categoria categoria);
    }

    public AdaptadorCategorias(List<Categoria> categorias, OnCategoriaClickListener listener) {
        this.categorias = categorias;
        this.listener = listener;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView txtItemCategoria;

        public ViewHolder(View view) {
            super(view);
            txtItemCategoria = view.findViewById(R.id.txtItemCategoria);
        }

        public void bind(Categoria categoria, OnCategoriaClickListener listener) {
            txtItemCategoria.setText(categoria.getNome());
            itemView.setOnClickListener(v -> listener.onCategoriaClick(categoria));
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_categoria, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bind(categorias.get(position), listener);
    }

    @Override
    public int getItemCount() {
        return categorias.size();
    }
}
