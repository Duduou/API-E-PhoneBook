package com.example.e_phonebook;

import java.util.List;

public class TagsRequest {
    private List<Integer> tagIds;
    public TagsRequest(List<Integer> tagIds) {
        this.tagIds = tagIds;
    }
    public List<Integer> getTagIds() {
        return tagIds;
    }

}
