package com.example.e_phonebook;

public class Global {
    private static Global instance;

    private LoginRequest devLogin = new LoginRequest("duduif3107@gmail.com", "TCCarlosIvankioTSI2025");

    private Global() {}

    public static synchronized Global getInstance() {
        if (instance == null) {
            instance = new Global();
        }
        return instance;
    }

    public LoginRequest getDevLogin() {
        return devLogin;
    }
}
