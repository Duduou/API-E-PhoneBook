package com.example.e_phonebook;

public class PhotoResponse {
    private String foto;

    public String getFoto() {
        return foto;
    }
    public void setFoto(String foto) {
        this.foto = foto;
    }
}
