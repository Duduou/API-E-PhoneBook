package com.example.e_phonebook;

public class EstabelecimentoTag {
    private int id;
    private int estabelecimento_id;
    private int tag_id;

    public EstabelecimentoTag(int id, int estabelecimento_id, int tag_id) {
        this.id = id;
        this.estabelecimento_id = estabelecimento_id;
        this.tag_id = tag_id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEstabelecimento_id() {
        return estabelecimento_id;
    }

    public void setEstabelecimento_id(int estabelecimento_id) {
        this.estabelecimento_id = estabelecimento_id;
    }

    public int getTag_id() {
        return tag_id;
    }

    public void setTag_id(int tag_id) {
        this.tag_id = tag_id;
    }
}
