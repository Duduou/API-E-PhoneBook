package com.example.e_phonebook;

import java.io.Serializable;

public class Telefone implements Serializable {
    private int id;
    private int estabelecimento_id;
    private String numero;

    public Telefone(int id, int estabelecimento_id, String numero) {
        this.id = id;
        this.estabelecimento_id = estabelecimento_id;
        this.numero = numero;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEstabelecimento_id() {
        return estabelecimento_id;
    }

    public void setEstabelecimento_id(int estabelecimento_id) {
        this.estabelecimento_id = estabelecimento_id;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }
}
